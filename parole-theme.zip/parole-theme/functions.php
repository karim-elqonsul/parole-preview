<?php
/**
 * PARŌLE theme bootstrap.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

define( 'PAROLE_VERSION', '1.0.0' );
define( 'PAROLE_DIR', get_template_directory() );
define( 'PAROLE_URI', get_template_directory_uri() );

require PAROLE_DIR . '/inc/icons.php';
require PAROLE_DIR . '/inc/setup.php';
require PAROLE_DIR . '/inc/fonts.php';
require PAROLE_DIR . '/inc/assets.php';
require PAROLE_DIR . '/inc/customizer.php';
require PAROLE_DIR . '/inc/template-tags.php';
require PAROLE_DIR . '/inc/contact-form.php';
require PAROLE_DIR . '/inc/patterns.php';
require PAROLE_DIR . '/inc/branches.php';
require PAROLE_DIR . '/inc/emenu.php';
require PAROLE_DIR . '/inc/social.php';
require PAROLE_DIR . '/inc/activation.php';

if ( class_exists( 'WooCommerce' ) ) {
	require PAROLE_DIR . '/inc/woocommerce.php';
	require PAROLE_DIR . '/inc/woocommerce-product-fields.php';
	require PAROLE_DIR . '/inc/woocommerce-filters.php';
	require PAROLE_DIR . '/inc/woocommerce-cart.php';
	require PAROLE_DIR . '/inc/woocommerce-checkout.php';
}
