<?php
/**
 * Template Name: الفروع (Branches)
 * Template Post Type: page
 *
 * Branch cards come from Admin → الفروع (one entry per branch). The page content
 * (optional) appears as the intro paragraph. The electronic-menu CTA uses
 * Customize → PARŌLE → الفوتر والتواصل → "رابط المنيو الإلكتروني".
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	$parole_eye   = get_post_meta( get_the_ID(), 'parole_eyebrow', true );
	$parole_count = count( parole_branches() );
	?>
	<main id="main" class="wrap page-pad branches">
		<?php parole_page_breadcrumb( get_the_title() ); ?>
		<header class="branches__head">
			<div class="branches__intro">
				<?php echo parole_eyebrow( $parole_eye ? $parole_eye : 'Our cafés' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<h1 class="page-title"><?php the_title(); ?></h1>
				<?php if ( '' !== trim( get_the_content() ) ) : ?>
					<div class="branches__lead"><?php the_content(); ?></div>
				<?php elseif ( $parole_count ) : ?>
					<p class="branches__lead">
						<?php
						/* translators: %d: number of branches */
						echo esc_html( sprintf( _n( '%d فرع لبارولي كافيه — العنوان ورقم التواصل وساعات العمل والموقع لكل فرع.', '%d فروع لبارولي كافيه — العنوان ورقم التواصل وساعات العمل والموقع لكل فرع.', $parole_count, 'parole' ), $parole_count ) );
						?>
					</p>
				<?php endif; ?>
			</div>
			<div class="branches__ctas">
				<?php echo parole_menu_link( __( 'عرض المنيو الإلكتروني', 'parole' ), 'btn btn--navy', 'menu-book' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php $parole_phone = parole_support_phone(); ?>
				<?php if ( $parole_phone ) : ?>
					<a class="btn btn--soft" href="<?php echo esc_url( 'tel:' . $parole_phone['tel'] ); ?>"><?php parole_the_icon( 'phone' ); ?><?php esc_html_e( 'خدمة العملاء', 'parole' ); ?> <span dir="ltr" class="u-en"><?php echo esc_html( $parole_phone['display'] ); ?></span></a>
				<?php endif; ?>
			</div>
		</header>
		<?php parole_render_branches( array( 'heading_level' => 2 ) ); ?>
	</main>
	<?php
endwhile;
get_footer();
