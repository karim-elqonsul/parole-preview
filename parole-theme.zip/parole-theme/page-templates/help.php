<?php
/**
 * Template Name: المساعدة (Help & FAQ)
 * Template Post Type: page
 *
 * Page content = FAQ (insert the "الأسئلة الشائعة" pattern). The side card is the
 * built-in contact form (sends to the admin email).
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	$parole_eye = get_post_meta( get_the_ID(), 'parole_eyebrow', true );
	?>
	<main id="main" class="wrap wrap--mid page-pad help">
		<?php parole_page_breadcrumb( get_the_title() ); ?>
		<header class="page-head page-head--intro">
			<?php echo parole_eyebrow( $parole_eye ? $parole_eye : 'Help & support' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<h1 class="page-title"><?php the_title(); ?></h1>
		</header>
		<div class="split split--help">
			<div class="entry-content help__faq"><?php the_content(); ?></div>
			<aside class="sticky-col"><?php echo parole_contact_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></aside>
		</div>
	</main>
	<?php
endwhile;
get_footer();
