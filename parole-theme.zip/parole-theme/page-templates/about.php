<?php
/**
 * Template Name: قصتنا (About)
 * Template Post Type: page
 *
 * Title, excerpt (lead), featured image and the page content are all edited in WordPress.
 * Tip: insert the "قيم بارولي" pattern for the four values.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	$parole_eye = get_post_meta( get_the_ID(), 'parole_eyebrow', true );
	?>
	<main id="main" class="wrap wrap--mid page-pad about">
		<?php parole_page_breadcrumb( get_the_title() ); ?>
		<header class="page-head page-head--intro">
			<?php echo parole_eyebrow( $parole_eye ? $parole_eye : 'About PARŌLE · since 2000' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<h1 class="page-title"><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?>
				<p class="page-lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>
		</header>
		<figure class="about__media">
			<?php
			echo has_post_thumbnail()
				? get_the_post_thumbnail( null, 'parole-hero', array( 'class' => 'cover', 'sizes' => '(max-width: 1140px) 100vw, 1140px' ) )
				: parole_default_picture( 'hero-stone', __( 'منتجات بارولي', 'parole' ), '(max-width: 1140px) 100vw, 1140px', array( 'class' => 'cover' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</figure>
		<div class="entry-content about__content"><?php the_content(); ?></div>
		<div class="btn-row about__actions">
			<?php if ( class_exists( 'WooCommerce' ) ) : ?>
				<a class="btn btn--navy" href="<?php echo esc_url( parole_category_url( 'beans' ) ); ?>"><?php esc_html_e( 'تسوّق المحاصيل', 'parole' ); ?></a>
			<?php endif; ?>
			<?php $parole_br = parole_template_url( 'page-templates/branches.php' ); ?>
			<?php if ( $parole_br ) : ?>
				<a class="btn btn--outline" href="<?php echo esc_url( $parole_br ); ?>"><?php esc_html_e( 'فروعنا', 'parole' ); ?></a>
			<?php endif; ?>
		</div>
	</main>
	<?php
endwhile;
get_footer();
