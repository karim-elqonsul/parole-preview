<?php
/**
 * Site footer + global overlays.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;
$parole_phone = parole_support_phone();
$parole_social = parole_social_row( 'social--footer' );
?>
<footer class="site-footer">
	<div class="wrap site-footer__top">
		<div class="site-footer__brand">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'بارولي — الرئيسية', 'parole' ); ?>"><?php echo parole_logo( 'footer-logo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			<?php if ( parole_mod( 'footer_tagline' ) ) : ?>
				<p class="site-footer__tagline"><?php echo esc_html( parole_mod( 'footer_tagline' ) ); ?></p>
			<?php endif; ?>
			<?php if ( parole_mod( 'newsletter' ) ) : ?>
				<div class="newsletter"><?php echo do_shortcode( wp_kses_post( parole_mod( 'newsletter' ) ) ); ?></div>
			<?php endif; ?>
			<?php if ( $parole_phone ) : ?>
				<div class="support-line">
					<span class="support-line__label"><?php esc_html_e( 'خدمة العملاء', 'parole' ); ?></span>
					<a class="support-line__tel" href="<?php echo esc_url( 'tel:' . $parole_phone['tel'] ); ?>" dir="ltr" aria-label="<?php echo esc_attr( sprintf( /* translators: %s phone */ __( 'اتصل بخدمة العملاء %s', 'parole' ), $parole_phone['display'] ) ); ?>"><?php parole_the_icon( 'phone' ); ?><?php echo esc_html( $parole_phone['display'] ); ?></a>
				</div>
			<?php endif; ?>
			<?php if ( $parole_social ) : ?>
				<div class="follow">
					<span class="follow__label"><?php esc_html_e( 'تابع بارولي', 'parole' ); ?></span>
					<?php echo $parole_social; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			<?php endif; ?>
		</div>
		<div class="site-footer__cols">
			<?php
			foreach ( array( 'footer-1', 'footer-2', 'footer-3' ) as $parole_loc ) {
				parole_footer_column( $parole_loc );
			}
			?>
		</div>
	</div>
	<div class="wrap site-footer__bottom">
		<span class="site-footer__copy"><?php echo esc_html( str_replace( '{year}', wp_date( 'Y' ), parole_mod( 'copyright' ) ) ); ?></span>
		<?php echo parole_payment_marks( 'paymarks paymarks--footer' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</div>
</footer>
</div><!-- .page -->

<?php
get_template_part( 'template-parts/header/search-overlay' );
get_template_part( 'template-parts/header/mobile-menu' );
if ( class_exists( 'WooCommerce' ) ) {
	get_template_part( 'template-parts/header/cart-drawer' );
}
?>
<div class="toast" role="status" aria-live="polite" data-toast hidden><?php parole_the_icon( 'check-circle' ); ?><span data-toast-text></span></div>

<?php wp_footer(); ?>
</body>
</html>
