<?php
/**
 * Search overlay. Works as a plain product-search form without JS; with JS it shows live
 * results from the WooCommerce Store API.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;
$parole_has_wc = class_exists( 'WooCommerce' );
?>
<div class="overlay overlay--search" id="search-overlay" data-overlay="search" hidden>
	<div class="overlay__backdrop" data-close></div>
	<div class="search-panel" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'بحث', 'parole' ); ?>">
		<div class="wrap search-panel__inner">
			<form class="search-panel__form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-search-form>
				<?php parole_the_icon( 'search', 'search-panel__icon' ); ?>
				<label class="screen-reader-text" for="parole-search-input"><?php esc_html_e( 'بحث', 'parole' ); ?></label>
				<input id="parole-search-input" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'ابحث عن محصول، ظرف، أو أداة', 'parole' ); ?>" autocomplete="off" data-search-input>
				<?php if ( $parole_has_wc ) : ?>
					<input type="hidden" name="post_type" value="product">
				<?php endif; ?>
				<button type="button" class="search-panel__clear" data-search-clear hidden><?php esc_html_e( 'مسح', 'parole' ); ?></button>
				<button type="button" class="search-panel__close" data-close aria-label="<?php esc_attr_e( 'إغلاق البحث', 'parole' ); ?>"><span class="desk-only" dir="ltr">ESC</span><?php parole_the_icon( 'x' ); ?></button>
			</form>

			<div class="search-panel__idle" data-search-idle>
				<?php
				$parole_chips = array();
				foreach ( array( 'beans', 'easy', 'tools', 'goods', 'bundles' ) as $parole_role ) {
					$parole_t = function_exists( 'parole_category' ) ? parole_category( $parole_role ) : null;
					if ( $parole_t ) {
						$parole_chips[] = $parole_t;
					}
				}
				if ( $parole_chips ) :
					?>
					<span class="search-panel__label"><?php esc_html_e( 'الأقسام', 'parole' ); ?></span>
					<div class="chips">
						<?php foreach ( $parole_chips as $parole_t ) : ?>
							<a class="chip" href="<?php echo esc_url( get_term_link( $parole_t ) ); ?>"><?php echo esc_html( $parole_t->name ); ?></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
			<div class="search-panel__status" data-search-status aria-live="polite"></div>
			<ul class="search-results" data-search-results role="list"></ul>
			<a href="#" class="btn btn--outline search-panel__all" data-search-all hidden><?php esc_html_e( 'عرض كل النتائج', 'parole' ); ?><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></a>
		</div>
	</div>
</div>
