<?php
/**
 * Off-canvas cart. The inner .widget_shopping_cart_content is WooCommerce's own mini-cart
 * fragment, refreshed by wc-cart-fragments after every cart change.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="overlay overlay--cart" id="cart-drawer" data-overlay="cart" hidden>
	<div class="overlay__backdrop" data-close></div>
	<aside class="drawer" role="dialog" aria-modal="true" aria-labelledby="cart-drawer-title">
		<div class="drawer__head">
			<h2 class="drawer__title" id="cart-drawer-title"><?php esc_html_e( 'سلتك', 'parole' ); ?></h2>
			<button type="button" class="round-btn" data-close aria-label="<?php esc_attr_e( 'إغلاق', 'parole' ); ?>"><?php parole_the_icon( 'x' ); ?></button>
		</div>
		<div class="widget_shopping_cart_content">
			<?php
			if ( ! is_cart() && ! is_checkout() ) {
				woocommerce_mini_cart();
			}
			?>
		</div>
	</aside>
</div>
