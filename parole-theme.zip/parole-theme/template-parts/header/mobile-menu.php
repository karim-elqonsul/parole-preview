<?php
/**
 * Full-screen mobile menu.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="overlay overlay--menu" id="mobile-menu" data-overlay="menu" hidden>
	<div class="mobile-menu" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'القائمة', 'parole' ); ?>">
		<div class="mobile-menu__head">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'بارولي — الرئيسية', 'parole' ); ?>"><?php echo parole_logo( 'mobile-menu__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			<button type="button" class="round-btn" data-close aria-label="<?php esc_attr_e( 'إغلاق', 'parole' ); ?>"><?php parole_the_icon( 'x' ); ?></button>
		</div>
		<nav class="mobile-menu__nav" aria-label="<?php esc_attr_e( 'الأقسام', 'parole' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'primary-nav__list',
					'depth'          => 1,
					'link_after'     => parole_icon( 'arrow-left', 'dir-icon' ),
					'fallback_cb'    => 'parole_menu_fallback',
				)
			);
			?>
		</nav>
		<div class="mobile-menu__foot">
			<button type="button" class="btn btn--soft" data-open="search" aria-controls="search-overlay"><?php parole_the_icon( 'search' ); ?><?php esc_html_e( 'بحث', 'parole' ); ?></button>
			<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
				<a class="btn btn--soft" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"><?php parole_the_icon( 'user' ); ?><?php esc_html_e( 'حسابي', 'parole' ); ?></a>
			<?php endif; ?>
		</div>
		<?php
		$parole_phone  = parole_support_phone();
		$parole_social = parole_social_row( 'social--menu' );
		if ( $parole_phone || $parole_social ) :
			?>
			<div class="mobile-menu__contact">
				<?php if ( $parole_phone ) : ?>
					<a class="support-line__tel" href="<?php echo esc_url( 'tel:' . $parole_phone['tel'] ); ?>"><?php parole_the_icon( 'phone' ); ?><span><?php esc_html_e( 'خدمة العملاء', 'parole' ); ?></span> <span dir="ltr"><?php echo esc_html( $parole_phone['display'] ); ?></span></a>
				<?php endif; ?>
				<?php echo $parole_social; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		<?php endif; ?>
	</div>
</div>
