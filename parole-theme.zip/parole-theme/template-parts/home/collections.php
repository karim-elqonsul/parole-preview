<?php
/**
 * "Shop by section" mosaic — WooCommerce product categories (image = category thumbnail).
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_roles = array(
	'beans'   => 'parole-beans-bags',
	'bundles' => 'parole-discovery-box',
	'easy'    => 'parole-easy-brew',
	'tools'   => 'parole-tools',
	'goods'   => 'parole-goods',
);
$parole_tiles = array();
foreach ( $parole_roles as $parole_role => $parole_fallback ) {
	$parole_t = parole_category( $parole_role );
	if ( $parole_t ) {
		$parole_tiles[] = array( $parole_t, $parole_fallback );
	}
}
if ( ! $parole_tiles ) {
	if ( current_user_can( 'manage_woocommerce' ) ) {
		echo '<p class="wrap admin-hint">' . esc_html__( 'تنبيه للمدير: أنشئ تصنيفات المنتجات أو اربطها من «تخصيص ← PARŌLE ← الأقسام والتصنيفات» لتظهر هنا.', 'parole' ) . '</p>';
	}
	return;
}
?>
<section class="wrap section section--first">
	<?php parole_section_head( parole_mod( 'col_eyebrow' ), parole_mod( 'col_title' ) ); ?>
	<div class="mosaic mosaic--<?php echo (int) count( $parole_tiles ); ?>">
		<?php
		foreach ( $parole_tiles as $parole_i => $parole_tile ) :
			list( $parole_t, $parole_fallback ) = $parole_tile;
			$parole_thumb = (int) get_term_meta( $parole_t->term_id, 'thumbnail_id', true );
			$parole_big   = 0 === $parole_i;
			$parole_en    = parole_term_en( $parole_t );
			$parole_sub   = $parole_big ? wp_strip_all_tags( term_description( $parole_t ) ) : '';
			?>
			<a class="tile<?php echo $parole_big ? ' tile--big' : ''; ?>" href="<?php echo esc_url( get_term_link( $parole_t ) ); ?>">
				<span class="tile__media"><?php echo parole_image( $parole_thumb, $parole_fallback, '', $parole_big ? '(max-width: 1100px) 100vw, 50vw' : '(max-width: 760px) 50vw, 25vw', array(), 'parole-tile' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span class="tile__shade" aria-hidden="true"></span>
				<span class="tile__body">
					<span class="tile__text">
						<?php echo parole_eyebrow( $parole_en, 'eyebrow--beige tile__eye' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span class="tile__title"><?php echo esc_html( $parole_t->name ); ?></span>
						<?php if ( $parole_sub ) : ?>
							<span class="tile__sub"><?php echo esc_html( $parole_sub ); ?></span>
						<?php endif; ?>
					</span>
					<span class="tile__arrow" aria-hidden="true"><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></span>
				</span>
			</a>
		<?php endforeach; ?>
	</div>
</section>
