<?php
/**
 * Campaign split (Discovery box). Product, price and add-to-cart come from WooCommerce.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_product = absint( parole_mod( 'camp_product' ) ) ? wc_get_product( absint( parole_mod( 'camp_product' ) ) ) : null;
if ( ! $parole_product || ! $parole_product->is_visible() ) {
	return;
}
$parole_img   = absint( parole_mod( 'camp_image' ) ) ? absint( parole_mod( 'camp_image' ) ) : $parole_product->get_image_id();
$parole_chips = array_filter( array_map( 'trim', preg_split( '/[,،]/u', (string) parole_mod( 'camp_chips' ) ) ) );
?>
<section class="wrap section">
	<div class="split split--campaign">
		<div class="split__media reveal" data-reveal>
			<?php echo parole_image( $parole_img, 'parole-discovery-box', $parole_product->get_name(), '(max-width: 760px) 100vw, 55vw', array( 'class' => 'cover' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
		<div class="split__copy">
			<?php echo parole_eyebrow( parole_mod( 'camp_eyebrow' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<div class="campaign__title">
				<?php if ( parole_mod( 'camp_number' ) ) : ?>
					<span class="campaign__num" dir="ltr" aria-hidden="true"><?php echo esc_html( parole_mod( 'camp_number' ) ); ?></span>
				<?php endif; ?>
				<h2 class="section-title"><?php echo esc_html( parole_mod( 'camp_title' ) ); ?></h2>
			</div>
			<?php if ( $parole_chips ) : ?>
				<ul class="pills" role="list">
					<?php foreach ( $parole_chips as $parole_c ) : ?>
						<li class="pill"><?php echo esc_html( $parole_c ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<div class="campaign__buy">
				<span class="campaign__price price"><?php echo wp_kses_post( $parole_product->get_price_html() ); ?></span>
				<?php if ( $parole_product->is_type( 'simple' ) && $parole_product->is_purchasable() && $parole_product->is_in_stock() ) : ?>
					<a href="<?php echo esc_url( $parole_product->add_to_cart_url() ); ?>" data-quantity="1" data-product_id="<?php echo esc_attr( $parole_product->get_id() ); ?>" data-product_sku="<?php echo esc_attr( $parole_product->get_sku() ); ?>" class="btn btn--navy btn--lg add_to_cart_button ajax_add_to_cart" rel="nofollow" aria-label="<?php echo esc_attr( sprintf( /* translators: %s product */ __( 'أضف %s إلى السلة', 'parole' ), $parole_product->get_name() ) ); ?>"><?php parole_the_icon( 'bag' ); ?><span class="btn__label"><?php esc_html_e( 'أضف إلى السلة', 'parole' ); ?></span></a>
				<?php else : ?>
					<a class="btn btn--navy btn--lg" href="<?php echo esc_url( $parole_product->get_permalink() ); ?>"><?php parole_the_icon( 'bag' ); ?><?php echo esc_html( $parole_product->add_to_cart_text() ); ?></a>
				<?php endif; ?>
				<a class="link-underline" href="<?php echo esc_url( $parole_product->get_permalink() ); ?>"><?php echo esc_html( parole_mod( 'camp_details' ) ); ?></a>
			</div>
		</div>
	</div>
</section>
