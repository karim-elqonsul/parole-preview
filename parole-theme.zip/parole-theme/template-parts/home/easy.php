<?php
/**
 * Easy-brew split rail.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_term     = parole_category( 'easy' );
$parole_products = parole_category_products( $parole_term, 3 );
if ( ! $parole_products ) {
	return;
}
?>
<section class="wrap section">
	<div class="split split--rail">
		<div class="split__intro sticky-col">
			<?php echo parole_eyebrow( parole_mod( 'easy_eyebrow' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<h2 class="section-title"><?php echo esc_html( parole_mod( 'easy_title' ) ); ?></h2>
			<?php if ( parole_mod( 'easy_text' ) ) : ?>
				<p class="split__text"><?php echo esc_html( parole_mod( 'easy_text' ) ); ?></p>
			<?php endif; ?>
			<a class="link-arrow" href="<?php echo esc_url( get_term_link( $parole_term ) ); ?>"><?php echo esc_html( parole_mod( 'easy_link' ) ); ?><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></a>
		</div>
		<ul class="products rail rail--3" role="list">
			<?php
			foreach ( $parole_products as $parole_p ) {
				parole_render_card( $parole_p );
			}
			wp_reset_postdata();
			?>
		</ul>
	</div>
</section>
