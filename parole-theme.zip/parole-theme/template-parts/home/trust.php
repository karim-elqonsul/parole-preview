<?php
/**
 * Payment reassurance strip — shows only logos uploaded in the Customizer.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_marks = parole_payment_marks( 'paymarks paymarks--strip' );
if ( ! $parole_marks ) {
	return;
}
?>
<section class="wrap trust" aria-label="<?php esc_attr_e( 'طرق الدفع', 'parole' ); ?>">
	<span class="trust__text"><?php parole_the_icon( 'lock' ); ?><?php echo esc_html( parole_mod( 'trust_text' ) ); ?></span>
	<?php echo $parole_marks; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</section>
