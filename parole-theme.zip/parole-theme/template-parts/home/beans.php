<?php
/**
 * Coffee beans rail.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_term     = parole_category( 'beans' );
$parole_products = parole_category_products( $parole_term, max( 2, min( 8, absint( parole_mod( 'beans_count' ) ) ) ) );
if ( ! $parole_products ) {
	return;
}
?>
<section class="wrap section">
	<?php parole_section_head( parole_mod( 'beans_eyebrow' ), parole_mod( 'beans_title' ), get_term_link( $parole_term ), parole_mod( 'beans_link' ) ); ?>
	<ul class="products rail rail--4" role="list">
		<?php
		foreach ( $parole_products as $parole_p ) {
			parole_render_card( $parole_p );
		}
		wp_reset_postdata();
		?>
	</ul>
</section>
