<?php
/**
 * Tools & goods rail: two brewing tools + two PARŌLE goods (fills from either if one is short).
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_tools_t = parole_category( 'tools' );
$parole_goods_t = parole_category( 'goods' );
$parole_tools   = parole_category_products( $parole_tools_t, 4 );
$parole_goods   = parole_category_products( $parole_goods_t, 4 );
$parole_items   = array_merge( array_slice( $parole_tools, 0, 2 ), array_slice( $parole_goods, 0, 2 ) );
$parole_rest    = array_merge( array_slice( $parole_tools, 2 ), array_slice( $parole_goods, 2 ) );
while ( count( $parole_items ) < 4 && $parole_rest ) {
	$parole_items[] = array_shift( $parole_rest );
}
if ( ! $parole_items ) {
	return;
}
$parole_link = $parole_tools_t ? get_term_link( $parole_tools_t ) : get_term_link( $parole_goods_t );
?>
<section class="wrap section section--last">
	<?php parole_section_head( parole_mod( 'tg_eyebrow' ), parole_mod( 'tg_title' ), is_wp_error( $parole_link ) ? '' : $parole_link, parole_mod( 'tg_link' ) ); ?>
	<ul class="products rail rail--4" role="list">
		<?php
		foreach ( $parole_items as $parole_p ) {
			parole_render_card( $parole_p );
		}
		wp_reset_postdata();
		?>
	</ul>
</section>
