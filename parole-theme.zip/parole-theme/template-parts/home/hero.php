<?php
/**
 * Hero — one scene on desktop/tablet, its own composition on mobile (as approved).
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_img_id  = absint( parole_mod( 'hero_image' ) );
$parole_alt     = __( 'كيس قهوة بارولي وفنجان على حجر طبيعي', 'parole' );
$parole_overlay = ! $parole_img_id && parole_mod( 'hero_logo_overlay' );
$parole_cta_url = parole_mod( 'hero_cta_url' ) ? parole_mod( 'hero_cta_url' ) : parole_category_url( 'beans' );

$parole_pid     = absint( parole_mod( 'hero_product' ) ) ? absint( parole_mod( 'hero_product' ) ) : absint( parole_mod( 'camp_product' ) );
$parole_product = ( $parole_pid && function_exists( 'wc_get_product' ) ) ? wc_get_product( $parole_pid ) : null;
if ( $parole_product && ! $parole_product->is_visible() ) {
	$parole_product = null;
}
$parole_info      = $parole_product ? parole_product_info( $parole_product ) : array();
$parole_link_text = parole_mod( 'hero_link_label' ) ? parole_mod( 'hero_link_label' ) : ( $parole_product ? $parole_product->get_name() : '' );

/**
 * Scene image markup (uploaded or bundled), shared by both compositions.
 *
 * @param string $class   Class.
 * @param string $sizes   sizes.
 * @param bool   $lazy    Lazy-load.
 */
$parole_scene = function ( $class, $sizes, $lazy ) use ( $parole_img_id, $parole_alt ) {
	$attr = array(
		'class'         => $class,
		'loading'       => $lazy ? 'lazy' : 'eager',
		'fetchpriority' => $lazy ? '' : 'high',
	);
	return parole_image( $parole_img_id, 'hero-stone', $parole_alt, $sizes, $attr, 'parole-hero' );
};

/**
 * Brand marks drawn onto the scene: logo on the bag, steam, the gold line.
 * Coordinates are in the 1586×992 space of the default photograph.
 *
 * @param string $viewbox ViewBox.
 * @param bool   $full    Include the line + dot.
 */
$parole_marks = function ( $viewbox, $full ) use ( $parole_overlay ) {
	?>
	<svg class="hero__marks" viewBox="<?php echo esc_attr( $viewbox ); ?>" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">
		<?php if ( $parole_overlay ) : ?>
			<image href="<?php echo esc_url( PAROLE_URI . '/assets/images/parole-logo-official.png' ); ?>" x="478" y="338" width="188" height="88"></image>
			<g class="hero__steam" data-steam>
				<circle cx="862" cy="470" r="16"></circle>
				<?php if ( $full ) : ?>
					<circle cx="880" cy="476" r="12"></circle>
				<?php endif; ?>
			</g>
		<?php endif; ?>
		<?php if ( $full && $parole_overlay ) : ?>
			<path class="hero__line" d="M1010 262 C 900 136, 690 118, 604 196 C 700 166, 828 246, 862 482" pathLength="1"></path>
			<circle class="hero__dot" cx="862" cy="482" r="4.5"></circle>
		<?php endif; ?>
	</svg>
	<?php
};

/**
 * Price card.
 *
 * @param string $class Class.
 */
$parole_card = function ( $class ) use ( $parole_product, $parole_info ) {
	if ( ! $parole_product ) {
		return;
	}
	?>
	<a class="hero-card <?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( $parole_product->get_permalink() ); ?>">
		<span class="hero-card__text">
			<span class="hero-card__name"><?php echo esc_html( $parole_product->get_name() ); ?></span>
			<?php if ( ! empty( $parole_info['origin'] ) ) : ?>
				<span class="hero-card__meta"><?php echo esc_html( $parole_info['origin'] ); ?></span>
			<?php endif; ?>
		</span>
		<span class="hero-card__rule" aria-hidden="true"></span>
		<span class="hero-card__price price"><?php echo wp_kses_post( $parole_product->get_price_html() ); ?></span>
	</a>
	<?php
};
?>
<section class="hero hero--desk desk-only" data-hero aria-label="<?php echo esc_attr( parole_mod( 'hero_title_1' ) . ' ' . parole_mod( 'hero_title_2' ) ); ?>">
	<div class="hero__scroll" data-scroll-hero>
		<div class="hero__scene">
			<div class="hero__parallax">
				<?php echo $parole_scene( 'hero__img', '100vw', false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php $parole_marks( '0 0 1586 992', true ); ?>
			</div>
		</div>
	</div>
	<div class="hero__fade" aria-hidden="true"></div>
	<div class="wrap hero__content">
		<div class="hero__copy" data-scroll-text>
			<div class="hero__kicker anim-in" style="--d:300ms">
				<?php echo parole_eyebrow( parole_mod( 'hero_eyebrow' ), 'eyebrow--beige' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php if ( parole_mod( 'hero_kicker' ) ) : ?>
					<span class="hero__kicker-ar"><?php echo esc_html( parole_mod( 'hero_kicker' ) ); ?></span>
				<?php endif; ?>
			</div>
			<h1 class="hero__title">
				<span class="anim-mask" style="--d:420ms"><?php echo esc_html( parole_mod( 'hero_title_1' ) ); ?></span>
				<span class="anim-mask hero__title-accent" style="--d:540ms"><?php echo esc_html( parole_mod( 'hero_title_2' ) ); ?></span>
			</h1>
			<?php if ( parole_mod( 'hero_text' ) ) : ?>
				<p class="hero__text anim-in" style="--d:700ms"><?php echo esc_html( parole_mod( 'hero_text' ) ); ?></p>
			<?php endif; ?>
			<div class="hero__actions anim-in" style="--d:840ms;--dur:400ms">
				<a class="btn btn--beige btn--lg" href="<?php echo esc_url( $parole_cta_url ); ?>"><?php echo esc_html( parole_mod( 'hero_cta_label' ) ); ?><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></a>
				<?php if ( $parole_product && $parole_link_text ) : ?>
					<a class="hero__link" href="<?php echo esc_url( $parole_product->get_permalink() ); ?>"><?php echo esc_html( $parole_link_text ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php $parole_card( 'hero-card--desk hide-sm anim-in' ); ?>
</section>

<section class="hero hero--mob mob-only" aria-label="<?php echo esc_attr( parole_mod( 'hero_title_1' ) . ' ' . parole_mod( 'hero_title_2' ) ); ?>">
	<?php echo parole_eyebrow( parole_mod( 'hero_eyebrow' ), 'eyebrow--beige anim-in' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<p class="hero__title" role="heading" aria-level="1">
		<span class="anim-mask" style="--d:180ms;--dur:650ms"><?php echo esc_html( parole_mod( 'hero_title_1' ) ); ?></span>
		<span class="anim-mask hero__title-accent" style="--d:280ms;--dur:650ms"><?php echo esc_html( parole_mod( 'hero_title_2' ) ); ?></span>
	</p>
	<?php if ( parole_mod( 'hero_text_mobile' ) ) : ?>
		<p class="hero__text anim-in" style="--d:420ms;--dur:500ms"><?php echo esc_html( parole_mod( 'hero_text_mobile' ) ); ?></p>
	<?php endif; ?>
	<a class="btn btn--beige btn--lg btn--block anim-in" style="--d:520ms;--dur:400ms" href="<?php echo esc_url( $parole_cta_url ); ?>"><?php echo esc_html( parole_mod( 'hero_cta_label' ) ); ?><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></a>
	<div class="hero__frame anim-scene" style="--d:560ms;--dur:800ms">
		<?php echo $parole_scene( 'hero__img hero__img--crop', '(max-width: 760px) 180vw, 100vw', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php $parole_marks( '80 140 1000 860', false ); ?>
		<?php $parole_card( 'hero-card--mob' ); ?>
	</div>
</section>
