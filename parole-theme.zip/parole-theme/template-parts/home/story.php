<?php
/**
 * Story band ("Since 2000").
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

$parole_url = parole_mod( 'story_cta_url' ) ? parole_mod( 'story_cta_url' ) : parole_template_url( 'page-templates/branches.php' );
?>
<section class="story" aria-label="<?php echo esc_attr( parole_mod( 'story_line_1' ) ); ?>">
	<div class="wrap story__grid">
		<div class="story__copy">
			<?php if ( parole_mod( 'story_year' ) ) : ?>
				<span class="story__year desk-only sv" dir="ltr" aria-hidden="true"><?php echo esc_html( parole_mod( 'story_year' ) ); ?></span>
			<?php endif; ?>
			<span class="story__eyebrow eyebrow sv" dir="ltr" style="--r0:10%;--r1:45%"><span class="story__rule" aria-hidden="true"></span><?php echo esc_html( parole_mod( 'story_eyebrow' ) ); ?></span>
			<?php if ( parole_mod( 'story_year' ) ) : ?>
				<span class="story__year story__year--mob mob-only" dir="ltr" aria-hidden="true"><?php echo esc_html( parole_mod( 'story_year' ) ); ?></span>
			<?php endif; ?>
			<h2 class="story__title">
				<span class="sv" style="--r0:18%;--r1:58%"><?php echo esc_html( parole_mod( 'story_line_1' ) ); ?></span>
				<span class="sv" style="--r0:24%;--r1:64%"><?php echo esc_html( parole_mod( 'story_line_2' ) ); ?></span>
			</h2>
			<span class="story__bar sv" aria-hidden="true" style="--r0:28%;--r1:66%"></span>
			<div class="story__body sv" style="--r0:32%;--r1:72%">
				<?php if ( parole_mod( 'story_p1' ) ) : ?>
					<p><?php echo esc_html( parole_mod( 'story_p1' ) ); ?></p>
				<?php endif; ?>
				<?php if ( parole_mod( 'story_p2' ) ) : ?>
					<p><?php echo esc_html( parole_mod( 'story_p2' ) ); ?></p>
				<?php endif; ?>
			</div>
			<div class="story__actions sv" style="--r0:40%;--r1:80%">
				<?php if ( $parole_url && parole_mod( 'story_cta' ) ) : ?>
					<a class="btn-orbit" href="<?php echo esc_url( $parole_url ); ?>"><?php echo esc_html( parole_mod( 'story_cta' ) ); ?><span class="btn-orbit__dot"><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></span></a>
				<?php endif; ?>
				<?php echo parole_menu_link( __( 'استعرض المنيو', 'parole' ), 'link-underline story__menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</div>
		<figure class="story__media">
			<div class="story__frame">
				<div class="story__drift" data-drift>
					<?php echo parole_image( absint( parole_mod( 'story_image' ) ), 'parole-goods', __( 'منتجات بارولي على طاولة حجرية في ضوء دافئ', 'parole' ), '(max-width: 760px) 100vw, 56vw', array( 'class' => 'cover story__img' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<span class="story__tint" aria-hidden="true"></span>
			</div>
			<figure class="story__inset sv" style="--r0:45%;--r1:85%">
				<div class="story__inset-frame<?php echo absint( parole_mod( 'story_inset' ) ) ? '' : ' story__inset-frame--crop'; ?>">
					<?php echo parole_image( absint( parole_mod( 'story_inset' ) ), 'parole-tools', __( 'تفصيل التقطير', 'parole' ), '(max-width: 760px) 50vw, 20vw', array( 'class' => 'cover' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<?php if ( parole_mod( 'story_caption' ) ) : ?>
					<figcaption dir="ltr"><?php echo esc_html( parole_mod( 'story_caption' ) ); ?></figcaption>
				<?php endif; ?>
			</figure>
		</figure>
	</div>
</section>
