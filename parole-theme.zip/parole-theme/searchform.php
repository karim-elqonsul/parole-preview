<?php
/**
 * Search form (products when WooCommerce is active).
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;
$parole_id = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $parole_id ); ?>"><?php esc_html_e( 'بحث', 'parole' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $parole_id ); ?>" class="input" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'ابحث عن محصول، ظرف، أو أداة', 'parole' ); ?>">
	<?php if ( class_exists( 'WooCommerce' ) ) : ?>
		<input type="hidden" name="post_type" value="product">
	<?php endif; ?>
	<button type="submit" class="btn btn--navy"><?php parole_the_icon( 'search' ); ?><span><?php esc_html_e( 'بحث', 'parole' ); ?></span></button>
</form>
