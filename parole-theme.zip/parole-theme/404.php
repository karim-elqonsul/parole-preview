<?php
/**
 * 404.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="wrap wrap--tight page-pad">
	<div class="notfound">
		<span class="notfound__num" dir="ltr" aria-hidden="true">404</span>
		<h1 class="page-title"><?php esc_html_e( 'الصفحة غير موجودة', 'parole' ); ?></h1>
		<p class="page-lead"><?php esc_html_e( 'ربما تغيّر الرابط. خلّنا نرجعك لفنجانك.', 'parole' ); ?></p>
		<div class="btn-row">
			<a class="btn btn--navy" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'الرئيسية', 'parole' ); ?></a>
			<?php if ( class_exists( 'WooCommerce' ) ) : ?>
				<a class="btn btn--outline" href="<?php echo esc_url( parole_category_url( 'beans' ) ); ?>"><?php esc_html_e( 'تسوّق المحاصيل', 'parole' ); ?></a>
			<?php endif; ?>
		</div>
		<?php get_search_form(); ?>
	</div>
</main>
<?php
get_footer();
