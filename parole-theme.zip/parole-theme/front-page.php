<?php
/**
 * Homepage. Copy & imagery: Appearance → Customize → PARŌLE. Products, prices and
 * categories come from WooCommerce.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="home">
	<?php
	get_template_part( 'template-parts/home/hero' );
	get_template_part( 'template-parts/home/trust' );
	if ( class_exists( 'WooCommerce' ) ) {
		get_template_part( 'template-parts/home/collections' );
		get_template_part( 'template-parts/home/beans' );
		get_template_part( 'template-parts/home/campaign' );
		get_template_part( 'template-parts/home/easy' );
	}
	get_template_part( 'template-parts/home/story' );
	if ( class_exists( 'WooCommerce' ) ) {
		get_template_part( 'template-parts/home/tools-goods' );
	}

	// Optional extra content written in the static front page (Settings → Reading).
	if ( 'page' === get_option( 'show_on_front' ) && have_posts() ) {
		while ( have_posts() ) {
			the_post();
			if ( '' !== trim( get_the_content() ) ) {
				echo '<section class="wrap home-content entry-content">';
				the_content();
				echo '</section>';
			}
		}
	}
	?>
</main>
<?php
get_footer();
