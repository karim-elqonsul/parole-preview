<?php
/**
 * Archive template (categories, tags, dates, authors).
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="wrap wrap--narrow page-pad">
	<header class="page-head">
		<h1 class="page-title">
			<?php
			if ( is_home() && ! is_front_page() ) {
				single_post_title();
			} elseif ( is_archive() ) {
				echo esc_html( wp_strip_all_tags( get_the_archive_title() ) );
			} elseif ( is_search() ) {
				/* translators: %s: query */
				echo esc_html( sprintf( __( 'نتائج البحث: «%s»', 'parole' ), get_search_query() ) );
			} else {
				esc_html_e( 'المدوّنة', 'parole' );
			}
			?>
		</h1>
		<?php if ( is_archive() && get_the_archive_description() ) : ?>
			<div class="page-lead"><?php echo wp_kses_post( get_the_archive_description() ); ?></div>
		<?php endif; ?>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="post-list">
			<?php
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/page/post-card' );
			}
			?>
		</div>
		<?php
		the_posts_pagination(
			array(
				'prev_text' => parole_icon( 'caret-left', 'dir-icon flip' ) . '<span class="screen-reader-text">' . __( 'السابق', 'parole' ) . '</span>',
				'next_text' => '<span class="screen-reader-text">' . __( 'التالي', 'parole' ) . '</span>' . parole_icon( 'caret-left', 'dir-icon' ),
			)
		);
		?>
	<?php else : ?>
		<div class="empty-state">
			<?php parole_the_icon( 'search', 'empty-state__icon' ); ?>
			<p class="empty-state__title"><?php esc_html_e( 'لا توجد نتائج', 'parole' ); ?></p>
			<?php get_search_form(); ?>
		</div>
	<?php endif; ?>
</main>
<?php
get_footer();
