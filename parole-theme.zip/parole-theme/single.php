<?php
/**
 * Single post.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="wrap wrap--narrow page-pad">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
			<?php parole_page_breadcrumb( get_the_title() ); ?>
			<header class="page-head">
				<time class="post-card__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
				<h1 class="page-title"><?php the_title(); ?></h1>
			</header>
			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="single-post__media"><?php the_post_thumbnail( 'large' ); ?></figure>
			<?php endif; ?>
			<div class="entry-content">
				<?php
				the_content();
				wp_link_pages();
				?>
			</div>
			<?php
			the_post_navigation(
				array(
					'prev_text' => '<span class="nav-label">' . __( 'السابق', 'parole' ) . '</span>%title',
					'next_text' => '<span class="nav-label">' . __( 'التالي', 'parole' ) . '</span>%title',
				)
			);
			?>
		</article>
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	endwhile;
	?>
</main>
<?php
get_footer();
