<?php
/**
 * Default page.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

get_header();
$parole_wc_page = function_exists( 'is_woocommerce' ) && ( is_cart() || is_checkout() || is_account_page() );
?>
<main id="main" class="wrap <?php echo $parole_wc_page ? 'wc-page' : 'wrap--narrow'; ?> page-pad">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<?php if ( ! $parole_wc_page ) : ?>
				<?php parole_page_breadcrumb( get_the_title() ); ?>
			<?php endif; ?>
			<header class="page-head<?php echo $parole_wc_page ? ' page-head--wc' : ''; ?>">
				<h1 class="page-title"><?php the_title(); ?></h1>
			</header>
			<div class="entry-content">
				<?php
				the_content();
				wp_link_pages();
				?>
			</div>
		</article>
		<?php
		if ( ! $parole_wc_page && ( comments_open() || get_comments_number() ) ) {
			comments_template();
		}
	endwhile;
	?>
</main>
<?php
get_footer();
