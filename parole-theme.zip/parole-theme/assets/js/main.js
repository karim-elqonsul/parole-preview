/**
 * PARŌLE front end. No framework. WooCommerce's own scripts (add-to-cart, cart-fragments)
 * do the commerce work; this file handles UI: overlays, toast, drawer quantities, live search,
 * product-page enhancements, hero parallax.
 */
(function () {
	'use strict';

	var CFG = window.PAROLE || {};
	var I18N = CFG.i18n || {};
	var $j = window.jQuery;
	var doc = document;
	var body = doc.body;
	var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function qs(sel, ctx) { return (ctx || doc).querySelector(sel); }
	function qsa(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }
	function fmt(str, val) { return String(str || '').replace(/%s|%d/, val); }
	function decode(html) { var t = doc.createElement('textarea'); t.innerHTML = html; return t.value; }

	/* ------------------------------------------------------------------ toast */
	var toastEl = qs('[data-toast]');
	var toastTimer;
	function toast(msg, isError) {
		if (!toastEl) return;
		qs('[data-toast-text]', toastEl).textContent = msg;
		toastEl.classList.toggle('is-error', !!isError);
		toastEl.hidden = false;
		// restart animation
		toastEl.style.animation = 'none'; void toastEl.offsetWidth; toastEl.style.animation = '';
		clearTimeout(toastTimer);
		toastTimer = setTimeout(function () { toastEl.hidden = true; }, 2200);
	}

	/* ---------------------------------------------------------------- header */
	var header = qs('[data-header]');
	if (header) {
		var ticking = false;
		var onScroll = function () {
			if (ticking) return;
			ticking = true;
			requestAnimationFrame(function () {
				ticking = false;
				header.classList.toggle('is-scrolled', window.scrollY > 8);
			});
		};
		window.addEventListener('scroll', onScroll, { passive: true });
		onScroll();
	}

	/* ------------------------------------------------------------ hero parallax */
	var hero = qs('[data-hero]');
	if (hero && !reduceMotion && window.matchMedia('(pointer: fine)').matches) {
		window.addEventListener('pointermove', function (e) {
			var r = hero.getBoundingClientRect();
			if (e.clientY > r.bottom || e.clientY < r.top) return;
			hero.style.setProperty('--mx', (((e.clientX - r.left) / r.width) * 2 - 1).toFixed(3));
			hero.style.setProperty('--my', (((e.clientY - r.top) / r.height) * 2 - 1).toFixed(3));
		}, { passive: true });
	}

	/* -------------------------------------------------------------- overlays */
	var openOverlay = null;
	var lastFocus = null;
	var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select, textarea, [tabindex]:not([tabindex="-1"])';

	function setExpanded(name, val) {
		qsa('[data-open="' + name + '"]').forEach(function (b) { b.setAttribute('aria-expanded', val ? 'true' : 'false'); });
	}
	function open(name, trigger) {
		var el = qs('[data-overlay="' + name + '"]');
		if (!el) return false;
		if (openOverlay && openOverlay !== el) close(true);
		lastFocus = trigger || doc.activeElement;
		el.hidden = false;
		openOverlay = el;
		body.classList.add('is-locked');
		setExpanded(name, true);
		var first = name === 'search' ? qs('[data-search-input]', el) : qs('[data-close], ' + FOCUSABLE, qs('[role="dialog"]', el));
		if (first) setTimeout(function () { first.focus(); }, 30);
		return true;
	}
	function close(silent) {
		if (!openOverlay) return;
		var name = openOverlay.getAttribute('data-overlay');
		openOverlay.hidden = true;
		openOverlay = null;
		body.classList.remove('is-locked');
		setExpanded(name, false);
		if (!silent && lastFocus && lastFocus.focus) lastFocus.focus();
	}

	doc.addEventListener('click', function (e) {
		var opener = e.target.closest('[data-open]');
		if (opener) {
			if (open(opener.getAttribute('data-open'), opener)) e.preventDefault();
			return;
		}
		if (e.target.closest('[data-close]') && openOverlay) {
			e.preventDefault();
			close();
		}
	});
	doc.addEventListener('keydown', function (e) {
		if (!openOverlay) return;
		if (e.key === 'Escape') { close(); return; }
		if (e.key !== 'Tab') return;
		var dialog = qs('[role="dialog"]', openOverlay) || openOverlay;
		var items = qsa(FOCUSABLE, dialog).filter(function (n) { return n.offsetParent !== null || n === doc.activeElement; });
		if (!items.length) return;
		var first = items[0], last = items[items.length - 1];
		if (e.shiftKey && doc.activeElement === first) { e.preventDefault(); last.focus(); }
		else if (!e.shiftKey && doc.activeElement === last) { e.preventDefault(); first.focus(); }
	});
	// Anchor links inside the mobile menu / sheets close the overlay.
	qsa('.mobile-menu__nav a, .sheet a').forEach(function (a) {
		a.addEventListener('click', function () { if (a.target !== '_blank') close(true); });
	});

	/* ---------------------------------------------------------- cart events */
	var cartBtn = qs('.cart-btn');
	function bump() {
		if (!cartBtn) cartBtn = qs('.cart-btn');
		if (!cartBtn) return;
		cartBtn.classList.remove('is-bump'); void cartBtn.offsetWidth; cartBtn.classList.add('is-bump');
	}
	function productNameFrom(btn) {
		var card = btn && btn.closest('.card, .product, .split__copy');
		var t = card && qs('.card__title, .product_title, .section-title', card);
		return t ? t.textContent.trim() : '';
	}
	function markAdded(btn) {
		if (!btn) return;
		var label = qs('.btn__label', btn) || btn;
		var original = label.getAttribute('data-label') || label.textContent;
		label.setAttribute('data-label', original);
		if (label === btn) {
			// keep any ::before glyph, change text node only
			btn.childNodes.forEach(function (n) { if (n.nodeType === 3 && n.textContent.trim()) n.textContent = I18N.addedShort; });
		} else {
			label.textContent = I18N.addedShort;
		}
		btn.classList.add('is-added');
		setTimeout(function () {
			btn.classList.remove('is-added', 'added');
			if (label === btn) {
				btn.childNodes.forEach(function (n) { if (n.nodeType === 3 && n.textContent.trim()) n.textContent = original.trim(); });
			} else {
				label.textContent = original;
			}
		}, 1400);
	}
	if ($j) {
		$j(body).on('added_to_cart', function (e, fragments, hash, $btn) {
			var btn = $btn && $btn[0];
			bump();
			markAdded(btn);
			var name = productNameFrom(btn);
			toast(name ? fmt(I18N.added, name) : I18N.addedShort);
		});
		$j(body).on('ajax_request_not_sent.adding_to_cart', function () { toast(I18N.error, true); });
	}

	/* Replace fragments returned by WooCommerce (same contract as wc-cart-fragments). */
	function applyFragments(data) {
		if (!data || !data.fragments) return;
		Object.keys(data.fragments).forEach(function (sel) {
			qsa(sel).forEach(function (node) {
				var tmp = doc.createElement('div');
				tmp.innerHTML = data.fragments[sel];
				if (tmp.firstElementChild) node.replaceWith(tmp.firstElementChild);
			});
		});
		if ($j) $j(body).trigger('wc_fragments_refreshed');
	}

	/* Drawer quantity steppers → ?wc-ajax=parole_set_qty */
	doc.addEventListener('click', function (e) {
		var btn = e.target.closest('[data-qty-inc], [data-qty-dec]');
		if (!btn || !CFG.wcAjax) return;
		var item = btn.closest('[data-key]');
		var val = qs('[data-qty-val]', item);
		var cur = parseInt(val.textContent, 10) || 1;
		var next = btn.hasAttribute('data-qty-inc') ? cur + 1 : cur - 1;
		var wrap = btn.closest('.widget_shopping_cart_content');
		if (wrap) wrap.classList.add('is-busy');
		var fd = new FormData();
		fd.append('key', item.getAttribute('data-key'));
		fd.append('qty', String(Math.max(0, next)));
		fd.append('nonce', CFG.qtyNonce);
		fetch(CFG.wcAjax.replace('%%endpoint%%', 'parole_set_qty'), { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
			.then(function (res) {
				if (!res.ok || res.j.success === false) {
					toast((res.j.data && res.j.data.message) || I18N.error, true);
					return;
				}
				applyFragments(res.j);
				bump();
			})
			.catch(function () { toast(I18N.error, true); })
			.then(function () { var w = qs('.overlay--cart .widget_shopping_cart_content'); if (w) w.classList.remove('is-busy'); });
	});

	/* ---------------------------------------------------------- live search */
	var sForm = qs('[data-search-form]');
	if (sForm) {
		var sInput = qs('[data-search-input]', sForm);
		var sClear = qs('[data-search-clear]', sForm);
		var sIdle = qs('[data-search-idle]');
		var sStatus = qs('[data-search-status]');
		var sList = qs('[data-search-results]');
		var sAll = qs('[data-search-all]');
		var timer, ctrl;

		var render = function (q, items) {
			sList.innerHTML = '';
			if (!items.length) {
				sStatus.className = 'search-panel__status is-none';
				sStatus.innerHTML = '';
				var t = doc.createElement('span'); t.className = 'none-title'; t.textContent = fmt(I18N.noResults, q);
				var h = doc.createElement('span'); h.className = 'none-hint'; h.textContent = I18N.noResultsHint;
				sStatus.append(t, h);
				sAll.hidden = true;
				return;
			}
			sStatus.className = 'search-panel__status';
			sStatus.textContent = fmt(I18N.results, items.length);
			items.slice(0, 6).forEach(function (p) {
				var li = doc.createElement('li');
				var a = doc.createElement('a'); a.className = 'search-result'; a.href = p.permalink;
				var th = doc.createElement('span'); th.className = 'search-result__thumb';
				if (p.images && p.images[0]) {
					var img = doc.createElement('img');
					img.src = p.images[0].thumbnail || p.images[0].src; img.alt = ''; img.loading = 'lazy'; img.width = 54; img.height = 54;
					th.appendChild(img);
				}
				var tx = doc.createElement('span'); tx.className = 'search-result__text';
				var nm = doc.createElement('span'); nm.className = 'search-result__name'; nm.textContent = decode(p.name);
				var ct = doc.createElement('span'); ct.className = 'search-result__cat';
				ct.textContent = (p.categories || []).map(function (c) { return decode(c.name); }).join(' · ');
				tx.append(nm, ct);
				var pr = doc.createElement('span'); pr.className = 'price';
				pr.innerHTML = p.price_html || ''; // server-rendered by WooCommerce Store API
				a.append(th, tx, pr);
				li.appendChild(a);
				sList.appendChild(li);
			});
			sAll.href = CFG.searchUrl + '&s=' + encodeURIComponent(q);
			sAll.hidden = false;
		};

		var run = function () {
			var q = sInput.value.trim();
			sClear.hidden = !sInput.value;
			sIdle.hidden = !!q;
			if (ctrl) ctrl.abort();
			if (!q) { sList.innerHTML = ''; sStatus.textContent = ''; sStatus.className = 'search-panel__status'; sAll.hidden = true; return; }
			if (!CFG.storeApi || !window.fetch) return;
			sStatus.className = 'search-panel__status is-loading';
			sStatus.textContent = I18N.loading;
			ctrl = window.AbortController ? new AbortController() : null;
			fetch(CFG.storeApi + (CFG.storeApi.indexOf('?') > -1 ? '&' : '?') + 'per_page=8&search=' + encodeURIComponent(q), { signal: ctrl && ctrl.signal, credentials: 'same-origin' })
				.then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
				.then(function (items) { if (sInput.value.trim() === q) render(q, items || []); })
				.catch(function (err) { if (err && err.name === 'AbortError') return; sStatus.className = 'search-panel__status'; sStatus.textContent = ''; });
		};
		sInput.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(run, 220); });
		sClear.addEventListener('click', function () { sInput.value = ''; run(); sInput.focus(); });
	}

	/* -------------------------------------------------------- product page */
	var form = qs('.pdp form.cart');

	// Quantity steppers around WooCommerce's native quantity input.
	qsa('.pdp .quantity, .woocommerce-cart-form .quantity').forEach(function (q) {
		var input = qs('input.qty', q);
		if (!input || input.type === 'hidden' || q.querySelector('.stepper__btn')) return;
		q.classList.add('stepper', 'stepper--lg');
		var mk = function (cls, label, icon, delta) {
			var b = doc.createElement('button');
			b.type = 'button'; b.className = 'stepper__btn ' + cls; b.setAttribute('aria-label', label);
			b.innerHTML = icon;
			b.addEventListener('click', function () {
				var step = parseFloat(input.step) || 1;
				var min = input.min !== '' ? parseFloat(input.min) : 0;
				var max = input.max !== '' ? parseFloat(input.max) : Infinity;
				var v = (parseFloat(input.value) || 0) + delta * step;
				input.value = Math.min(max, Math.max(min, v));
				input.dispatchEvent(new Event('change', { bubbles: true }));
				if ($j) $j(input).trigger('change');
			});
			return b;
		};
		var minusSvg = '<svg class="icon" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128Z"/></svg>';
		var plusSvg = '<svg class="icon" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z"/></svg>';
		q.insertBefore(mk('stepper__dec', 'تقليل', minusSvg, -1), input);
		q.appendChild(mk('stepper__inc', 'زيادة', plusSvg, 1));
	});

	// Variation selects → pill buttons (select stays as the source of truth for WooCommerce).
	qsa('.pdp table.variations select').forEach(function (sel) {
		var group = doc.createElement('div');
		group.className = 'opt-pills';
		group.setAttribute('role', 'radiogroup');
		var lbl = sel.closest('tr') && qs('th label, .label label', sel.closest('tr'));
		if (lbl) group.setAttribute('aria-label', lbl.textContent.trim());
		var build = function () {
			group.innerHTML = '';
			Array.prototype.forEach.call(sel.options, function (o) {
				if (!o.value) return;
				var b = doc.createElement('button');
				b.type = 'button'; b.className = 'opt-pill'; b.textContent = o.text;
				b.setAttribute('role', 'radio');
				b.setAttribute('aria-checked', sel.value === o.value ? 'true' : 'false');
				if (o.disabled) b.disabled = true;
				b.addEventListener('click', function () {
					sel.value = sel.value === o.value ? '' : o.value;
					if ($j) $j(sel).trigger('change'); else sel.dispatchEvent(new Event('change', { bubbles: true }));
				});
				group.appendChild(b);
			});
		};
		sel.classList.add('is-enhanced');
		sel.insertAdjacentElement('afterend', group);
		build();
		if ($j) {
			$j(sel).on('change', build);
			$j(sel).closest('form').on('woocommerce_update_variation_values reset_data', function () { setTimeout(build, 0); });
		} else {
			sel.addEventListener('change', build);
		}
	});

	// AJAX add-to-cart on the product page (uses WooCommerce's normal form handler).
	if (form && window.fetch && !form.classList.contains('grouped_form') && !form.querySelector('input[type="file"]')) {
		form.addEventListener('submit', function (e) {
			var submitter = qs('.single_add_to_cart_button', form);
			if (!submitter || submitter.classList.contains('disabled')) return; // WooCommerce shows its own message.
			e.preventDefault();
			var fd = new FormData(form);
			if (!fd.has('add-to-cart') && submitter.value) fd.append('add-to-cart', submitter.value);
			submitter.classList.add('loading');
			fetch(form.action || window.location.href, { method: 'POST', body: fd, credentials: 'same-origin' })
				.then(function (r) { return r.text(); })
				.then(function (html) {
					var tmp = new DOMParser().parseFromString(html, 'text/html');
					var err = qs('.woocommerce-error li, .woocommerce-error, .wc-block-components-notice-banner.is-error', tmp);
					if (err) { toast(err.textContent.trim().replace(/\s+/g, ' '), true); return; }
					if ($j) $j(body).trigger('wc_fragment_refresh');
					bump();
					markAdded(submitter);
					var title = qs('.product_title');
					toast(fmt(I18N.added, title ? title.textContent.trim() : ''));
				})
				.catch(function () { form.submit(); })
				.then(function () { submitter.classList.remove('loading'); });
		});
	}

	// Mobile sticky buy bar mirrors the main form.
	var buyBtn = qs('[data-buybar-add]');
	if (buyBtn && form) {
		buyBtn.addEventListener('click', function () {
			var submit = qs('.single_add_to_cart_button', form);
			if (submit && submit.classList.contains('disabled')) {
				form.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
				toast(I18N.chooseOpts, true);
				return;
			}
			if (form.requestSubmit) form.requestSubmit(submit); else submit.click();
		});
	}

	/* -------------------------------------------------- checkout summary toggle */
	doc.addEventListener('click', function (e) {
		var t = e.target.closest('[data-summary-toggle]');
		if (!t) return;
		var target = doc.getElementById(t.getAttribute('aria-controls'));
		var openNow = t.getAttribute('aria-expanded') !== 'true';
		t.setAttribute('aria-expanded', openNow ? 'true' : 'false');
		if (target) target.classList.toggle('is-open', openNow);
	});
})();
