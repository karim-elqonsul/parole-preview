<?php
/**
 * Branches: a WordPress-native "Branches" post type (Admin → الفروع).
 * One branch = one entry with structured fields. Order = "Order" (menu_order) field.
 * Initial content = the official spreadsheet "Parole (6 Branches) 2026.xlsx", imported once.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Field definitions: meta key => [label, type, description].
 */
function parole_branch_fields() {
	return array(
		'_branch_name_ar' => array( __( 'الاسم بالعربية (اختياري)', 'parole' ), 'text', __( 'يظهر كعنوان رئيسي، والاسم الرسمي (عنوان المنشور) يظهر فوقه بالإنجليزية.', 'parole' ) ),
		'_branch_address' => array( __( 'العنوان', 'parole' ), 'text', '' ),
		'_branch_phone'   => array( __( 'رقم الهاتف', 'parole' ), 'tel', __( 'مثال: +966 558512256', 'parole' ) ),
		'_branch_open'    => array( __( 'يفتح الساعة', 'parole' ), 'time', '' ),
		'_branch_close'   => array( __( 'يغلق الساعة', 'parole' ), 'time', '' ),
		'_branch_hours'   => array( __( 'ملاحظة ساعات العمل (اختياري)', 'parole' ), 'text', __( 'مثال: الجمعة من 1 ظهرًا — تظهر تحت الساعات.', 'parole' ) ),
		'_branch_maps'    => array( __( 'رابط خرائط Google', 'parole' ), 'url', '' ),
	);
}

add_action( 'init', 'parole_register_branches' );
function parole_register_branches() {
	register_post_type(
		'parole_branch',
		array(
			'labels'             => array(
				'name'               => __( 'الفروع', 'parole' ),
				'singular_name'      => __( 'فرع', 'parole' ),
				'add_new'            => __( 'إضافة فرع', 'parole' ),
				'add_new_item'       => __( 'إضافة فرع جديد', 'parole' ),
				'edit_item'          => __( 'تعديل الفرع', 'parole' ),
				'all_items'          => __( 'كل الفروع', 'parole' ),
				'search_items'       => __( 'بحث في الفروع', 'parole' ),
				'not_found'          => __( 'لا توجد فروع', 'parole' ),
				'not_found_in_trash' => __( 'لا توجد فروع في المهملات', 'parole' ),
			),
			'public'             => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'show_in_rest'       => false,
			'menu_position'      => 21,
			'menu_icon'          => 'dashicons-location',
			'supports'           => array( 'title', 'page-attributes' ),
			'capability_type'    => 'page',
			'map_meta_cap'       => true,
		)
	);
	foreach ( parole_branch_fields() as $key => $def ) {
		register_post_meta(
			'parole_branch',
			$key,
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'url' === $def[1] ? 'esc_url_raw' : 'sanitize_text_field',
				'auth_callback'     => function () {
					return current_user_can( 'edit_pages' );
				},
			)
		);
	}
}

add_filter(
	'enter_title_here',
	function ( $text, $post ) {
		return 'parole_branch' === $post->post_type ? __( 'اسم الفرع الرسمي (مثال: Al Wadi)', 'parole' ) : $text;
	},
	10,
	2
);

/* ---------------------------------------------------------------------------
 * Edit screen fields.
 * ------------------------------------------------------------------------- */
add_action(
	'add_meta_boxes_parole_branch',
	function () {
		add_meta_box( 'parole_branch_details', __( 'بيانات الفرع', 'parole' ), 'parole_branch_metabox', 'parole_branch', 'normal', 'high' );
	}
);

/**
 * @param WP_Post $post Post.
 */
function parole_branch_metabox( $post ) {
	wp_nonce_field( 'parole_branch_save', 'parole_branch_nonce' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( parole_branch_fields() as $key => $def ) {
		$val = get_post_meta( $post->ID, $key, true );
		$dir = in_array( $def[1], array( 'tel', 'url', 'time' ), true ) ? ' dir="ltr"' : '';
		printf(
			'<tr><th scope="row"><label for="%1$s">%2$s</label></th><td><input type="%3$s" id="%1$s" name="%1$s" value="%4$s" class="regular-text"%5$s>%6$s</td></tr>',
			esc_attr( $key ),
			esc_html( $def[0] ),
			esc_attr( $def[1] ),
			esc_attr( $val ),
			$dir, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$def[2] ? '<p class="description">' . esc_html( $def[2] ) . '</p>' : ''
		);
	}
	echo '</tbody></table><p class="description">' . esc_html__( 'ترتيب الظهور: حقل «الترتيب» في صندوق «خصائص الصفحة». لإخفاء فرع: انقله إلى «مسودة» أو احذفه.', 'parole' ) . '</p>';
}

add_action(
	'save_post_parole_branch',
	function ( $post_id ) {
		if ( ! isset( $_POST['parole_branch_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['parole_branch_nonce'] ) ), 'parole_branch_save' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		foreach ( parole_branch_fields() as $key => $def ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$val = 'url' === $def[1] ? esc_url_raw( $raw ) : sanitize_text_field( $raw );
			if ( 'time' === $def[1] && '' !== $val && ! preg_match( '/^\d{2}:\d{2}$/', $val ) ) {
				continue;
			}
			update_post_meta( $post_id, $key, $val );
		}
	}
);

/* Admin list columns. */
add_filter(
	'manage_parole_branch_posts_columns',
	function ( $cols ) {
		return array(
			'cb'            => $cols['cb'],
			'title'         => __( 'الفرع', 'parole' ),
			'branch_addr'   => __( 'العنوان', 'parole' ),
			'branch_phone'  => __( 'الهاتف', 'parole' ),
			'branch_hours'  => __( 'ساعات العمل', 'parole' ),
			'menu_order'    => __( 'الترتيب', 'parole' ),
		);
	}
);
add_action(
	'manage_parole_branch_posts_custom_column',
	function ( $col, $id ) {
		$b = parole_get_branch( get_post( $id ) );
		if ( 'branch_addr' === $col ) {
			echo esc_html( $b['address'] );
		} elseif ( 'branch_phone' === $col ) {
			echo '<span dir="ltr">' . esc_html( $b['phone'] ) . '</span>';
		} elseif ( 'branch_hours' === $col ) {
			echo '<span dir="ltr">' . esc_html( $b['hours'] ) . '</span>';
		} elseif ( 'menu_order' === $col ) {
			echo (int) get_post_field( 'menu_order', $id );
		}
	},
	10,
	2
);
add_action(
	'pre_get_posts',
	function ( $q ) {
		if ( is_admin() && $q->is_main_query() && 'parole_branch' === $q->get( 'post_type' ) && ! $q->get( 'orderby' ) ) {
			$q->set( 'orderby', 'menu_order' );
			$q->set( 'order', 'ASC' );
		}
	}
);

/* ---------------------------------------------------------------------------
 * Data access.
 * ------------------------------------------------------------------------- */

/**
 * Normalised branch record.
 *
 * @param WP_Post $post Branch post.
 * @return array<string,string>
 */
function parole_get_branch( $post ) {
	$m     = function ( $k ) use ( $post ) {
		return trim( (string) get_post_meta( $post->ID, $k, true ) );
	};
	$open  = $m( '_branch_open' );
	$close = $m( '_branch_close' );
	$phone = $m( '_branch_phone' );
	return array(
		'id'      => (string) $post->ID,
		'name'    => get_the_title( $post ),
		'name_ar' => $m( '_branch_name_ar' ),
		'address' => $m( '_branch_address' ),
		'phone'   => $phone,
		'tel'     => preg_replace( '/[^\d+]/', '', $phone ),
		'open'    => $open,
		'close'   => $close,
		'hours'   => ( $open && $close ) ? $open . ' – ' . $close : '',
		'note'    => $m( '_branch_hours' ),
		'maps'    => $m( '_branch_maps' ),
		'slug'    => 'branch-' . sanitize_title( get_the_title( $post ) ),
	);
}

/**
 * Published branches in display order.
 *
 * @return array<int,array<string,string>>
 */
function parole_branches() {
	$posts = get_posts(
		array(
			'post_type'      => 'parole_branch',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
			'no_found_rows'  => true,
		)
	);
	return array_map( 'parole_get_branch', $posts );
}

/* ---------------------------------------------------------------------------
 * One-time import of the official spreadsheet.
 * ------------------------------------------------------------------------- */

/**
 * Official data — "Parole (6 Branches) 2026.xlsx", sheet "2026". Values verbatim
 * (Work Time 0 → 00:00, 0.999305… → 23:59). Used only to seed an empty install.
 */
function parole_branch_seed_data() {
	$rows = array(
		array( 'Al Wadi', 'Exit 7, Othman Ibn Affan Branch Road', '+966 558512256', 'https://maps.app.goo.gl/PJrNRek9ovmRcyWFA' ),
		array( 'Al Hamra', 'Exit 9, Khaled Ibn Alwaleed Street', '+966 562975534', 'https://maps.app.goo.gl/aq6nzskxPgZNw7i48' ),
		array( 'Al Mansorah', 'Mohamed ibn Shoail Street', '+966 558497866', 'https://maps.app.goo.gl/xWrnC9wzSk5ZSUPA8' ),
		array( 'Al Aziziya', 'Mohammad Rashid Rida Street', '+966 558567860', 'https://maps.app.goo.gl/wdi9PS4118Hx8c5q8' ),
		array( 'Al Dar Al Bida', 'Arafat Road', '+966 502215285', 'https://maps.app.goo.gl/JdZinE32VbSUnk2c7' ),
		array( 'Tuwaiq', 'Al Zahabi Street', '+966 596251988', 'https://maps.app.goo.gl/DwgTzw31KYUxbX2t5' ),
	);
	$out = array();
	foreach ( $rows as $i => $r ) {
		$out[] = array(
			'title' => $r[0],
			'order' => $i + 1,
			'meta'  => array(
				'_branch_address' => $r[1],
				'_branch_phone'   => $r[2],
				'_branch_open'    => '00:00',
				'_branch_close'   => '23:59',
				'_branch_maps'    => $r[3],
			),
		);
	}
	return $out;
}

/**
 * Import the official branches if none exist. Idempotent.
 *
 * @return int Number created.
 */
function parole_seed_branches() {
	parole_register_branches();
	$existing = get_posts(
		array(
			'post_type'      => 'parole_branch',
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'fields'         => 'ids',
		)
	);
	if ( $existing ) {
		return 0;
	}
	$n = 0;
	foreach ( parole_branch_seed_data() as $b ) {
		$id = wp_insert_post(
			array(
				'post_type'   => 'parole_branch',
				'post_status' => 'publish',
				'post_title'  => $b['title'],
				'menu_order'  => $b['order'],
			),
			true
		);
		if ( ! is_wp_error( $id ) ) {
			foreach ( $b['meta'] as $k => $v ) {
				update_post_meta( $id, $k, $v );
			}
			++$n;
		}
	}
	update_option( 'parole_branches_seeded', time(), false );
	return $n;
}
add_action( 'after_switch_theme', 'parole_seed_branches' );

/* Admin notice with an "import" button when the list is empty (e.g. after deleting all). */
add_action(
	'admin_notices',
	function () {
		$screen = get_current_screen();
		if ( ! $screen || 'edit-parole_branch' !== $screen->id || ! current_user_can( 'edit_pages' ) ) {
			return;
		}
		$count = wp_count_posts( 'parole_branch' );
		if ( array_sum( (array) $count ) > 0 ) {
			return;
		}
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=parole_import_branches' ), 'parole_import_branches' );
		echo '<div class="notice notice-info"><p>' . esc_html__( 'لا توجد فروع. يمكنك استيراد الفروع الستة الرسمية (من ملف Parole Branches 2026).', 'parole' ) . ' <a class="button button-primary" href="' . esc_url( $url ) . '">' . esc_html__( 'استيراد الفروع الرسمية', 'parole' ) . '</a></p></div>';
	}
);
add_action(
	'admin_post_parole_import_branches',
	function () {
		check_admin_referer( 'parole_import_branches' );
		if ( ! current_user_can( 'edit_pages' ) ) {
			wp_die( esc_html__( 'غير مسموح.', 'parole' ) );
		}
		parole_seed_branches();
		wp_safe_redirect( admin_url( 'edit.php?post_type=parole_branch' ) );
		exit;
	}
);

/* ---------------------------------------------------------------------------
 * Front end.
 * ------------------------------------------------------------------------- */

/**
 * Branch cards grid.
 *
 * @param array $args { heading_level: int }.
 */
function parole_render_branches( $args = array() ) {
	$branches = parole_branches();
	if ( ! $branches ) {
		if ( current_user_can( 'edit_pages' ) ) {
			echo '<p class="admin-hint">' . esc_html__( 'تنبيه للمدير: أضف الفروع من لوحة التحكم ← الفروع.', 'parole' ) . '</p>';
		}
		return;
	}
	$h      = isset( $args['heading_level'] ) ? (int) $args['heading_level'] : 2;
	$new_tab = '<span class="screen-reader-text"> ' . esc_html__( '(يفتح في نافذة جديدة)', 'parole' ) . '</span>';
	?>
	<nav class="branch-jump" aria-label="<?php esc_attr_e( 'الانتقال إلى فرع', 'parole' ); ?>">
		<ul class="chips" role="list">
			<?php foreach ( $branches as $b ) : ?>
				<li><a class="chip" href="#<?php echo esc_attr( $b['slug'] ); ?>"><?php echo esc_html( $b['name_ar'] ? $b['name_ar'] : $b['name'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</nav>
	<ul class="branch-grid" role="list">
		<?php foreach ( $branches as $i => $b ) : ?>
			<li class="branch-card" id="<?php echo esc_attr( $b['slug'] ); ?>">
				<div class="branch-card__head">
					<span class="branch-card__num" dir="ltr" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
					<div class="branch-card__names">
						<?php if ( $b['name_ar'] ) : ?>
							<span class="eyebrow" dir="ltr"><?php echo esc_html( $b['name'] ); ?></span>
							<?php printf( '<h%1$d class="branch-card__title">%2$s</h%1$d>', $h, esc_html( $b['name_ar'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php else : ?>
							<?php printf( '<h%1$d class="branch-card__title" dir="auto">%2$s</h%1$d>', $h, esc_html( $b['name'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endif; ?>
					</div>
				</div>
				<dl class="branch-card__rows">
					<?php if ( $b['address'] ) : ?>
						<div class="branch-row">
							<dt><?php parole_the_icon( 'map-pin' ); ?><span class="screen-reader-text"><?php esc_html_e( 'العنوان', 'parole' ); ?></span></dt>
							<dd dir="auto"><?php echo esc_html( $b['address'] ); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ( $b['phone'] ) : ?>
						<div class="branch-row">
							<dt><?php parole_the_icon( 'phone' ); ?><span class="screen-reader-text"><?php esc_html_e( 'الهاتف', 'parole' ); ?></span></dt>
							<dd><a class="branch-row__tel" href="<?php echo esc_url( 'tel:' . $b['tel'] ); ?>" dir="ltr" aria-label="<?php echo esc_attr( sprintf( /* translators: 1 branch, 2 phone */ __( 'اتصل بفرع %1$s على %2$s', 'parole' ), $b['name_ar'] ? $b['name_ar'] : $b['name'], $b['phone'] ) ); ?>"><?php echo esc_html( $b['phone'] ); ?></a></dd>
						</div>
					<?php endif; ?>
					<?php if ( $b['hours'] || $b['note'] ) : ?>
						<div class="branch-row">
							<dt><?php parole_the_icon( 'clock' ); ?><span class="screen-reader-text"><?php esc_html_e( 'ساعات العمل', 'parole' ); ?></span></dt>
							<dd>
								<?php if ( $b['hours'] ) : ?>
									<span class="branch-row__hours"><?php esc_html_e( 'ساعات العمل', 'parole' ); ?> <time dir="ltr"><?php echo esc_html( $b['hours'] ); ?></time></span>
								<?php endif; ?>
								<?php if ( $b['note'] ) : ?>
									<span class="branch-row__note"><?php echo esc_html( $b['note'] ); ?></span>
								<?php endif; ?>
							</dd>
						</div>
					<?php endif; ?>
				</dl>
				<?php if ( $b['maps'] ) : ?>
					<a class="btn btn--outline btn--block branch-card__map" href="<?php echo esc_url( $b['maps'] ); ?>" target="_blank" rel="noopener noreferrer">
						<?php parole_the_icon( 'map-pin' ); ?><?php esc_html_e( 'افتح في خرائط Google', 'parole' ); ?><?php echo $new_tab; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php parole_the_icon( 'external', 'branch-card__ext' ); ?>
					</a>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
}
add_shortcode(
	'parole_branches',
	function () {
		ob_start();
		parole_render_branches();
		return ob_get_clean();
	}
);
