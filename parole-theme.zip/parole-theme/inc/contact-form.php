<?php
/**
 * Help-page contact form ("راسلنا"). Sends via wp_mail to the site admin email
 * (filter: parole_contact_recipient). Nonce + honeypot + simple rate limit.
 * Use the [parole_contact] shortcode anywhere, or the Help page template.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render the form.
 */
function parole_contact_form() {
	$state = isset( $_GET['contact'] ) ? sanitize_key( wp_unslash( $_GET['contact'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	ob_start();
	echo parole_contact_channels(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	?>
	<div class="contact-card" id="contact">
		<h2 class="contact-card__title"><?php esc_html_e( 'راسلنا', 'parole' ); ?></h2>
		<?php if ( 'sent' === $state ) : ?>
			<p class="form-status form-status--ok" role="status"><?php parole_the_icon( 'check-circle' ); ?><?php esc_html_e( 'وصلتنا رسالتك، بنرد عليك قريبًا.', 'parole' ); ?></p>
		<?php else : ?>
			<?php if ( 'invalid' === $state ) : ?>
				<p class="form-status form-status--err" role="alert"><?php parole_the_icon( 'warning' ); ?><?php esc_html_e( 'أكمل بيانات التواصل والرسالة', 'parole' ); ?></p>
			<?php elseif ( 'error' === $state ) : ?>
				<p class="form-status form-status--err" role="alert"><?php parole_the_icon( 'warning' ); ?><?php esc_html_e( 'تعذّر الإرسال الآن، حاول لاحقًا أو راسلنا على إنستغرام.', 'parole' ); ?></p>
			<?php endif; ?>
			<form class="form-stack" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="parole_contact">
				<input type="hidden" name="redirect" value="<?php echo esc_url( get_permalink() ); ?>">
				<?php wp_nonce_field( 'parole_contact', 'parole_contact_nonce' ); ?>
				<p class="hp-field" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
				<label class="field"><span class="field__label"><?php esc_html_e( 'رقم الجوال أو البريد', 'parole' ); ?></span><input class="input" type="text" name="contact" required autocomplete="email" maxlength="120"></label>
				<label class="field"><span class="field__label"><?php esc_html_e( 'رسالتك', 'parole' ); ?></span><textarea class="input" name="message" rows="4" required maxlength="3000"></textarea></label>
				<button type="submit" class="btn btn--navy"><?php esc_html_e( 'إرسال', 'parole' ); ?></button>
			</form>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'parole_contact', 'parole_contact_form' );

/**
 * Handle submissions.
 */
function parole_contact_submit() {
	$back = isset( $_POST['redirect'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['redirect'] ) ), home_url( '/' ) ) : home_url( '/' );
	$go   = function ( $state ) use ( $back ) {
		wp_safe_redirect( add_query_arg( 'contact', $state, $back ) . '#contact' );
		exit;
	};

	if ( ! isset( $_POST['parole_contact_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['parole_contact_nonce'] ) ), 'parole_contact' ) ) {
		$go( 'error' );
	}
	if ( ! empty( $_POST['website'] ) ) { // Honeypot: pretend success.
		$go( 'sent' );
	}
	$contact = isset( $_POST['contact'] ) ? sanitize_text_field( wp_unslash( $_POST['contact'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
	if ( '' === $contact || '' === $message ) {
		$go( 'invalid' );
	}

	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'parole_contact_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		$go( 'error' );
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );

	$to      = apply_filters( 'parole_contact_recipient', get_option( 'admin_email' ) );
	$subject = sprintf( '[%s] %s', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), __( 'رسالة من صفحة المساعدة', 'parole' ) );
	$body    = __( 'التواصل:', 'parole' ) . ' ' . $contact . "\n\n" . $message;
	$headers = array();
	if ( is_email( $contact ) ) {
		$headers[] = 'Reply-To: ' . $contact;
	}
	$go( wp_mail( $to, $subject, $body, $headers ) ? 'sent' : 'error' );
}
add_action( 'admin_post_parole_contact', 'parole_contact_submit' );
add_action( 'admin_post_nopriv_parole_contact', 'parole_contact_submit' );
