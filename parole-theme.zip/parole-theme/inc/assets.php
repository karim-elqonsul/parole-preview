<?php
/**
 * Front-end CSS / JS.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cache-busting version: file mtime in development, theme version otherwise.
 *
 * @param string $rel Path relative to the theme.
 */
function parole_asset_ver( $rel ) {
	$file = PAROLE_DIR . '/' . $rel;
	return ( defined( 'WP_DEBUG' ) && WP_DEBUG && file_exists( $file ) ) ? (string) filemtime( $file ) : PAROLE_VERSION;
}

add_action( 'wp_enqueue_scripts', 'parole_enqueue_assets', 20 );
function parole_enqueue_assets() {
	wp_enqueue_style( 'parole-main', PAROLE_URI . '/assets/css/main.css', array(), parole_asset_ver( 'assets/css/main.css' ) );
	wp_add_inline_style( 'parole-main', parole_font_face_css() . parole_font_stack_css() );

	if ( class_exists( 'WooCommerce' ) ) {
		wp_enqueue_style( 'parole-woocommerce', PAROLE_URI . '/assets/css/woocommerce.css', array( 'parole-main' ), parole_asset_ver( 'assets/css/woocommerce.css' ) );
	}

	$deps = array();
	if ( class_exists( 'WooCommerce' ) ) {
		// WooCommerce's own cart scripts drive add-to-cart + fragments; we listen to their events.
		$deps = array( 'jquery', 'wc-cart-fragments' );
		wp_enqueue_script( 'wc-cart-fragments' );
		if ( 'yes' === get_option( 'woocommerce_enable_ajax_add_to_cart' ) ) {
			wp_enqueue_script( 'wc-add-to-cart' );
		}
	}
	wp_enqueue_script( 'parole-main', PAROLE_URI . '/assets/js/main.js', $deps, parole_asset_ver( 'assets/js/main.js' ), array( 'strategy' => 'defer', 'in_footer' => true ) );

	$data = array(
		'i18n' => array(
			'added'       => __( 'أُضيف %s إلى السلة', 'parole' ),
			'addedShort'  => __( 'تمت الإضافة', 'parole' ),
			'error'       => __( 'تعذّر تنفيذ الطلب، حاول مرة أخرى.', 'parole' ),
			'results'     => __( '%d نتيجة', 'parole' ),
			'noResults'   => __( 'ما لقينا «%s»', 'parole' ),
			'noResultsHint' => __( 'جرّب اسم محصول أو قسم آخر.', 'parole' ),
			'loading'     => __( 'جارٍ البحث…', 'parole' ),
			'chooseOpts'  => __( 'اختر الخيارات أولًا', 'parole' ),
		),
	);
	if ( class_exists( 'WooCommerce' ) ) {
		$data['storeApi']   = esc_url_raw( rest_url( 'wc/store/v1/products' ) );
		$data['wcAjax']     = esc_url_raw( WC_AJAX::get_endpoint( '%%endpoint%%' ) );
		$data['qtyNonce']   = wp_create_nonce( 'parole-cart-qty' );
		$data['searchUrl']  = esc_url_raw( add_query_arg( 'post_type', 'product', home_url( '/' ) ) );
		$data['currency']   = html_entity_decode( get_woocommerce_currency_symbol() );
	}
	wp_localize_script( 'parole-main', 'PAROLE', $data );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}

/**
 * Arabic font stack: licensed Dahab first only when its files are present.
 */
function parole_font_stack_css() {
	$ar = empty( parole_dahab_sources() ) ? "'Tajawal'" : "'Dahab Arabic ITF','Tajawal'";
	return ':root{--font-ar:' . $ar . ',system-ui,sans-serif;}';
}

/**
 * The theme ships a complete WooCommerce skin, so WooCommerce's generic stylesheets are not loaded.
 */
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * Block-library CSS only where blocks render (classic templates don't need the full sheet).
 */
add_filter( 'should_load_separate_core_block_assets', '__return_true' );
