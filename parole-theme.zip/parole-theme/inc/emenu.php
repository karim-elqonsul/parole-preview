<?php
/**
 * Official electronic café menu (external, menux.app). One setting — Customize → PARŌLE →
 * "المنيو الإلكتروني" — feeds every menu link: header nav, mobile menu, footer, Branches
 * page and the homepage story CTA. Never embedded (no iframe); always opens in a new tab.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * The configured menu URL ('' hides every menu link).
 */
function parole_menu_url() {
	return esc_url( trim( (string) parole_mod( 'menu_url' ) ) );
}

/**
 * External menu link markup.
 *
 * @param string $label Visible label.
 * @param string $class Classes.
 * @param string $icon  Leading icon key ('' for none).
 */
function parole_menu_link( $label, $class = '', $icon = '' ) {
	$url = parole_menu_url();
	if ( ! $url ) {
		return '';
	}
	return sprintf(
		'<a class="%1$s" href="%2$s" target="_blank" rel="noopener noreferrer">%3$s%4$s<span class="screen-reader-text"> %5$s</span>%6$s</a>',
		esc_attr( $class ),
		esc_url( $url ),
		$icon ? parole_icon( $icon ) : '',
		esc_html( $label ),
		esc_html__( '(يفتح في نافذة جديدة)', 'parole' ),
		parole_icon( 'external', 'ext-icon' )
	);
}

/**
 * Menu items with the CSS class "parole-emenu" always point at the setting (so editors can
 * reposition the item in Appearance → Menus without copying the URL).
 */
add_filter(
	'nav_menu_link_attributes',
	function ( $atts, $item ) {
		if ( in_array( 'parole-emenu', (array) $item->classes, true ) && parole_menu_url() ) {
			$atts['href']   = parole_menu_url();
			$atts['target'] = '_blank';
			$atts['rel']    = 'noopener noreferrer';
		}
		return $atts;
	},
	10,
	2
);
add_filter(
	'nav_menu_item_title',
	function ( $title, $item ) {
		if ( in_array( 'parole-emenu', (array) $item->classes, true ) ) {
			$title .= '<span class="screen-reader-text"> ' . esc_html__( '(يفتح في نافذة جديدة)', 'parole' ) . '</span>' . parole_icon( 'external', 'ext-icon' );
		}
		return $title;
	},
	10,
	2
);

/**
 * Auto-add the menu link to the main navigation (desktop + mobile) and footer column 3,
 * unless the assigned menu already contains a "parole-emenu" item or the option is off.
 */
add_filter(
	'wp_nav_menu_items',
	function ( $items, $args ) {
		if ( ! parole_mod( 'menu_in_nav' ) || ! parole_menu_url() || false !== strpos( $items, 'parole-emenu' ) ) {
			return $items;
		}
		if ( 'primary' === $args->theme_location ) {
			$after = isset( $args->link_after ) ? $args->link_after : '';
			return $items . '<li class="menu-item parole-emenu menu-item--external">' . str_replace( '</a>', $after . '</a>', parole_menu_link( __( 'المنيو', 'parole' ) ) ) . '</li>';
		}
		if ( 'footer-3' === $args->theme_location ) {
			return $items . '<li class="menu-item parole-emenu">' . parole_menu_link( __( 'المنيو الإلكتروني', 'parole' ) ) . '</li>';
		}
		return $items;
	},
	10,
	2
);
