<?php
/**
 * Theme supports, menus, image sizes.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', 'parole_setup' );
function parole_setup() {
	load_theme_textdomain( 'parole', PAROLE_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 372,
			'width'       => 797,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 600,
			'single_image_width'    => 1000,
			'product_grid'          => array(
				'default_rows'    => 4,
				'min_rows'        => 1,
				'default_columns' => 4,
				'min_columns'     => 2,
				'max_columns'     => 4,
			),
		)
	);
	add_theme_support( 'wc-product-gallery-slider' );
	add_theme_support( 'wc-product-gallery-lightbox' );

	add_editor_style( 'assets/css/editor.css' );

	register_nav_menus(
		array(
			'primary'  => __( 'القائمة الرئيسية (الهيدر والجوال)', 'parole' ),
			'footer-1' => __( 'الفوتر — العمود الأول', 'parole' ),
			'footer-2' => __( 'الفوتر — العمود الثاني', 'parole' ),
			'footer-3' => __( 'الفوتر — العمود الثالث', 'parole' ),
		)
	);

	// Wide hero / editorial crops (uploads replacing the defaults).
	add_image_size( 'parole-hero', 1920, 1200, false );
	add_image_size( 'parole-tile', 1200, 900, true );
}

/**
 * Product grid thumbnails are 4:5 portrait, as in the approved card.
 */
add_filter(
	'woocommerce_get_image_size_thumbnail',
	function ( $size ) {
		return array(
			'width'  => 600,
			'height' => 750,
			'crop'   => 1,
		);
	}
);
add_filter(
	'woocommerce_get_image_size_gallery_thumbnail',
	function () {
		return array(
			'width'  => 240,
			'height' => 240,
			'crop'   => 1,
		);
	}
);

/** Content width for embeds. */
add_action(
	'after_setup_theme',
	function () {
		$GLOBALS['content_width'] = 1240;
	},
	0
);

/** Excerpt length tuned for Arabic. */
add_filter(
	'excerpt_length',
	function () {
		return 28;
	}
);

/** Pages get an excerpt box (used as the lead paragraph on the About template). */
add_action(
	'init',
	function () {
		add_post_type_support( 'page', 'excerpt' );
	}
);
