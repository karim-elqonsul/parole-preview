<?php
/**
 * Header cart button, cart fragments, and quantity changes from the cart drawer.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Header cart button. Opens the drawer (JS); without JS it is a link to the cart page.
 */
function parole_cart_button() {
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$attrs = ( is_cart() || is_checkout() ) ? '' : ' data-open="cart" aria-controls="cart-drawer" aria-expanded="false" role="button"';
	printf(
		'<a class="cart-btn" href="%1$s"%2$s aria-label="%3$s">%4$s<span class="cart-btn__count" dir="ltr" data-cart-count>%5$d</span></a>',
		esc_url( wc_get_cart_url() ),
		$attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		/* translators: %d: items in cart */
		esc_attr( sprintf( _n( 'السلة — %d منتج', 'السلة — %d منتجات', $count, 'parole' ), $count ) ),
		parole_icon( 'bag' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		(int) $count
	);
}

/** Keep the count in sync through WooCommerce fragments. */
add_filter(
	'woocommerce_add_to_cart_fragments',
	function ( $fragments ) {
		$count                                    = WC()->cart->get_cart_contents_count();
		$fragments['span[data-cart-count]']       = '<span class="cart-btn__count" dir="ltr" data-cart-count>' . (int) $count . '</span>';
		return $fragments;
	}
);

/**
 * Cart-drawer quantity change: ?wc-ajax=parole_set_qty  (nonce-checked, uses the WC cart API).
 */
function parole_ajax_set_qty() {
	check_ajax_referer( 'parole-cart-qty', 'nonce' );
	$key = isset( $_POST['key'] ) ? wc_clean( wp_unslash( $_POST['key'] ) ) : '';
	$qty = isset( $_POST['qty'] ) ? wc_stock_amount( wp_unslash( $_POST['qty'] ) ) : 0; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$cart = WC()->cart;
	if ( ! $key || ! $cart || ! $cart->get_cart_item( $key ) ) {
		wp_send_json_error( array( 'message' => __( 'المنتج غير موجود في السلة.', 'parole' ) ), 400 );
	}
	if ( $qty <= 0 ) {
		$cart->remove_cart_item( $key );
	} else {
		$item    = $cart->get_cart_item( $key );
		$product = $item['data'];
		$passed  = apply_filters( 'woocommerce_update_cart_validation', true, $key, $item, $qty );
		if ( $passed && $product && $product->managing_stock() && ! $product->backorders_allowed() && $qty > $product->get_stock_quantity() ) {
			/* translators: %d: stock */
			wc_add_notice( sprintf( __( 'الكمية المتوفرة %d فقط.', 'parole' ), $product->get_stock_quantity() ), 'error' );
			$passed = false;
		}
		if ( ! $passed ) {
			$errors = wc_get_notices( 'error' );
			wc_clear_notices();
			$msg = $errors ? wp_strip_all_tags( is_array( $errors[0] ) ? $errors[0]['notice'] : $errors[0] ) : __( 'تعذّر تحديث الكمية.', 'parole' );
			wp_send_json_error( array( 'message' => $msg ), 400 );
		}
		$cart->set_quantity( $key, $qty, true );
	}
	WC_AJAX::get_refreshed_fragments(); // Sends JSON (fragments + cart_hash) and exits.
}
add_action( 'wc_ajax_parole_set_qty', 'parole_ajax_set_qty' );
