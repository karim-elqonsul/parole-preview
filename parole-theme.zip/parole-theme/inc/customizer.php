<?php
/**
 * Customizer: every piece of homepage copy, imagery and store presentation is editable here.
 * Appearance → Customize → "PARŌLE".
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Defaults (the approved design copy).
 */
function parole_defaults() {
	$defaults = array(
		// Hero.
		'hero_eyebrow'      => 'From origin to cup',
		'hero_kicker'       => 'قهوة مختصة من بارولي',
		'hero_title_1'      => 'من المحصول',
		'hero_title_2'      => 'إلى الفنجان',
		'hero_text'         => 'محاصيل مختصة، وأظرف تقطير جاهزة، وأدوات تحضير مختارة — لتحضّر فنجان بارولي في بيتك.',
		'hero_text_mobile'  => 'محاصيل مختصة وأظرف تقطير وأدوات تحضير — لفنجان بارولي في بيتك.',
		'hero_cta_label'    => 'تسوّق المحاصيل',
		'hero_cta_url'      => '',
		'hero_link_label'   => '',
		'hero_image'        => 0,
		'hero_logo_overlay' => true,
		'hero_product'      => 0,
		// Trust strip / payments.
		'trust_text'        => 'دفع آمن ومشفّر',
		'bnpl_text'         => 'ادفع الآن أو قسّطها مع',
		// Collections.
		'col_eyebrow'       => 'Collections',
		'col_title'         => 'تسوّق حسب القسم',
		'cat_beans'         => 0,
		'cat_bundles'       => 0,
		'cat_easy'          => 0,
		'cat_tools'         => 0,
		'cat_goods'         => 0,
		// Beans.
		'beans_eyebrow'     => 'Single origin · 250g',
		'beans_title'       => 'محاصيل بارولي',
		'beans_link'        => 'كل المحاصيل',
		'beans_count'       => 4,
		// Campaign.
		'camp_product'      => 0,
		'camp_eyebrow'      => 'Discovery box · 3 × 250g',
		'camp_number'       => '3',
		'camp_title'        => 'محاصيل في بوكس واحد',
		'camp_chips'        => 'إثيوبيا، كولومبيا، أوغندا',
		'camp_image'        => 0,
		'camp_details'      => 'التفاصيل',
		// Easy brew.
		'easy_eyebrow'      => 'Easy brew',
		'easy_title'        => 'أظرف بارولي',
		'easy_text'         => 'نفس المحاصيل في ظرف تقطير جاهز. ماء ساخن وكوب، وبس.',
		'easy_link'         => 'كل الأظرف',
		// Story.
		'story_eyebrow'     => 'Since 2000',
		'story_year'        => '2000',
		'story_line_1'      => 'القهوة ليست مجرد مشروب،',
		'story_line_2'      => 'بل طقس يومي ومساحة هادئة.',
		'story_p1'          => 'بارولي من كلمة «الكلام» — لأن القهوة دائمًا تجمع الناس.',
		'story_p2'          => 'ومنذ 2000، نحاول أن نرجّع للحظة البسيطة قيمتها وسط زحمة اليوم.',
		'story_cta'         => 'زورونا في الفروع',
		'story_cta_url'     => '',
		'story_image'       => 0,
		'story_inset'       => 0,
		'story_caption'     => 'The daily ritual',
		// Tools & goods.
		'tg_eyebrow'        => 'Tools & goods',
		'tg_title'          => 'أدوات التحضير ومنتجات بارولي',
		'tg_link'           => 'تسوّق الأدوات',
		// Brand / contact.
		'menu_url'          => 'https://menux.app/barwny-kafyh-parolecafee/',
		'menu_in_nav'       => true,
		'maps_url'          => 'https://www.google.com/maps/search/PAROLE+Cafe+%D8%A8%D8%A7%D8%B1%D9%88%D9%84%D9%8A',
		'footer_tagline'    => 'لحظة تستحق التكرار — قهوة مختصة من بارولي إلى بيتك.',
		'newsletter'        => '',
		'copyright'         => '© {year} بارولي · الأسعار شاملة الضريبة',
		// Store.
		'shipping_tab'      => 'تظهر خيارات الاستلام وتكلفتها في خطوة إتمام الطلب.',
		'simple_checkout'   => true,
		'sa_phone'          => true,
		'currency_label'    => 'SAR',
	);
	return apply_filters( 'parole_defaults_extra', $defaults );
}

/**
 * Read a theme mod with the design default.
 *
 * @param string $key Setting key.
 * @return mixed
 */
function parole_mod( $key ) {
	static $d = null;
	if ( null === $d || ! did_action( 'after_setup_theme' ) ) {
		$d = parole_defaults();
	}
	return get_theme_mod( 'parole_' . $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

/**
 * Payment / trust logo slots. Files are uploaded by the store owner (official brand kits).
 */
function parole_payment_slots() {
	return array(
		'mada'       => 'mada',
		'visa'       => 'Visa',
		'mastercard' => 'Mastercard',
		'applepay'   => 'Apple Pay',
		'stcpay'     => 'stc pay',
		'tabby'      => 'Tabby',
		'tamara'     => 'Tamara',
		'extra'      => __( 'شعار إضافي', 'parole' ),
	);
}

/**
 * Uploaded payment logos, in display order.
 *
 * @param string[]|null $only Restrict to these slots.
 * @return array<int,array{id:int,label:string,slot:string}>
 */
function parole_payment_logos( $only = null ) {
	$out = array();
	foreach ( parole_payment_slots() as $slot => $label ) {
		if ( $only && ! in_array( $slot, $only, true ) ) {
			continue;
		}
		$id = absint( get_theme_mod( 'parole_pay_' . $slot ) );
		if ( $id && wp_attachment_is_image( $id ) ) {
			$alt   = get_post_meta( $id, '_wp_attachment_image_alt', true );
			$out[] = array(
				'id'    => $id,
				'label' => $alt ? $alt : $label,
				'slot'  => $slot,
			);
		}
	}
	return $out;
}

add_action( 'customize_register', 'parole_customize_register' );
/**
 * Register panels / sections / controls.
 *
 * @param WP_Customize_Manager $wp_customize Manager.
 */
function parole_customize_register( $wp_customize ) {
	$d = parole_defaults();

	$wp_customize->add_panel(
		'parole',
		array(
			'title'    => 'PARŌLE',
			'priority' => 25,
		)
	);

	$add = function ( $section, $key, $label, $type = 'text', $extra = array() ) use ( $wp_customize, $d ) {
		$sanitize = array(
			'text'     => 'sanitize_text_field',
			'textarea' => 'sanitize_textarea_field',
			'url'      => 'esc_url_raw',
			'number'   => 'absint',
			'checkbox' => 'parole_sanitize_checkbox',
			'select'   => 'absint',
			'image'    => 'absint',
		);
		$wp_customize->add_setting(
			'parole_' . $key,
			array(
				'default'           => isset( $d[ $key ] ) ? $d[ $key ] : '',
				'sanitize_callback' => $sanitize[ $type ],
				'transport'         => 'refresh',
			)
		);
		if ( 'image' === $type ) {
			$wp_customize->add_control(
				new WP_Customize_Media_Control(
					$wp_customize,
					'parole_' . $key,
					array_merge(
						array(
							'label'     => $label,
							'section'   => $section,
							'mime_type' => 'image',
						),
						$extra
					)
				)
			);
			return;
		}
		$wp_customize->add_control(
			'parole_' . $key,
			array_merge(
				array(
					'label'   => $label,
					'section' => $section,
					'type'    => $type,
				),
				$extra
			)
		);
	};

	$sections = array(
		'parole_hero'     => __( 'الواجهة (Hero)', 'parole' ),
		'parole_trust'    => __( 'طرق الدفع وشريط الثقة', 'parole' ),
		'parole_cols'     => __( 'الأقسام والتصنيفات', 'parole' ),
		'parole_beans'    => __( 'قسم المحاصيل', 'parole' ),
		'parole_campaign' => __( 'الحملة (بوكس الاكتشاف)', 'parole' ),
		'parole_easy'     => __( 'قسم الأظرف', 'parole' ),
		'parole_story'    => __( 'القصة', 'parole' ),
		'parole_tg'       => __( 'الأدوات والمنتجات', 'parole' ),
		'parole_brand'    => __( 'الفوتر والتواصل', 'parole' ),
		'parole_store'    => __( 'إعدادات المتجر', 'parole' ),
	);
	$i = 10;
	foreach ( $sections as $id => $title ) {
		$wp_customize->add_section(
			$id,
			array(
				'title'    => $title,
				'panel'    => 'parole',
				'priority' => $i,
			)
		);
		$i += 10;
	}

	$cats     = array( 0 => __( '— تلقائي (حسب الرابط المختصر) —', 'parole' ) );
	$products = array( 0 => __( '— بدون —', 'parole' ) );
	if ( taxonomy_exists( 'product_cat' ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$cats[ $t->term_id ] = $t->name;
			}
		}
	}
	if ( function_exists( 'wc_get_products' ) ) {
		foreach ( wc_get_products(
			array(
				'limit'   => 300,
				'status'  => 'publish',
				'orderby' => 'title',
				'order'   => 'ASC',
			)
		) as $p ) {
			$products[ $p->get_id() ] = $p->get_name();
		}
	}

	// Hero.
	$add( 'parole_hero', 'hero_eyebrow', __( 'السطر الإنجليزي الصغير', 'parole' ) );
	$add( 'parole_hero', 'hero_kicker', __( 'السطر التمهيدي', 'parole' ) );
	$add( 'parole_hero', 'hero_title_1', __( 'العنوان — السطر الأول', 'parole' ) );
	$add( 'parole_hero', 'hero_title_2', __( 'العنوان — السطر الثاني (بيج)', 'parole' ) );
	$add( 'parole_hero', 'hero_text', __( 'النص (ديسكتوب)', 'parole' ), 'textarea' );
	$add( 'parole_hero', 'hero_text_mobile', __( 'النص (جوال)', 'parole' ), 'textarea' );
	$add( 'parole_hero', 'hero_cta_label', __( 'نص الزر', 'parole' ) );
	$add( 'parole_hero', 'hero_cta_url', __( 'رابط الزر (فارغ = قسم المحاصيل)', 'parole' ), 'url' );
	$add( 'parole_hero', 'hero_product', __( 'منتج بطاقة السعر', 'parole' ), 'select', array( 'choices' => $products, 'description' => __( 'يظهر اسمه وسعره الحالي من ووكومرس.', 'parole' ) ) );
	$add( 'parole_hero', 'hero_link_label', __( 'نص الرابط الثانوي (فارغ = اسم المنتج)', 'parole' ) );
	$add( 'parole_hero', 'hero_image', __( 'صورة الواجهة (1586×992 أو أكبر)', 'parole' ), 'image' );
	$add( 'parole_hero', 'hero_logo_overlay', __( 'إظهار الشعار على الكيس (للصورة الافتراضية فقط)', 'parole' ), 'checkbox' );

	// Trust.
	$add( 'parole_trust', 'trust_text', __( 'نص الأمان', 'parole' ) );
	$add( 'parole_trust', 'bnpl_text', __( 'نص التقسيط في صفحة المنتج', 'parole' ) );
	foreach ( parole_payment_slots() as $slot => $label ) {
		$add(
			'parole_trust',
			'pay_' . $slot,
			/* translators: %s: payment brand */
			sprintf( __( 'شعار %s (من الهوية الرسمية)', 'parole' ), $label ),
			'image',
			array( 'description' => __( 'SVG أو PNG شفاف. يُعرض فقط عند رفعه.', 'parole' ) )
		);
	}

	// Collections / category roles.
	$add( 'parole_cols', 'col_eyebrow', __( 'السطر الإنجليزي', 'parole' ) );
	$add( 'parole_cols', 'col_title', __( 'العنوان', 'parole' ) );
	$roles = array(
		'cat_beans'   => __( 'تصنيف المحاصيل — Coffee Beans', 'parole' ),
		'cat_bundles' => __( 'تصنيف الباقات والهدايا — Bundles & Gifts', 'parole' ),
		'cat_easy'    => __( 'تصنيف الأظرف — Easy Brew', 'parole' ),
		'cat_tools'   => __( 'تصنيف أدوات التحضير — Brewing Tools', 'parole' ),
		'cat_goods'   => __( 'تصنيف منتجات بارولي — PARŌLE Goods', 'parole' ),
	);
	foreach ( $roles as $key => $label ) {
		$add( 'parole_cols', $key, $label, 'select', array( 'choices' => $cats ) );
	}

	// Beans.
	$add( 'parole_beans', 'beans_eyebrow', __( 'السطر الإنجليزي', 'parole' ) );
	$add( 'parole_beans', 'beans_title', __( 'العنوان', 'parole' ) );
	$add( 'parole_beans', 'beans_link', __( 'نص الرابط', 'parole' ) );
	$add( 'parole_beans', 'beans_count', __( 'عدد المنتجات', 'parole' ), 'number', array( 'input_attrs' => array( 'min' => 2, 'max' => 8 ) ) );

	// Campaign.
	$add( 'parole_campaign', 'camp_product', __( 'المنتج', 'parole' ), 'select', array( 'choices' => $products ) );
	$add( 'parole_campaign', 'camp_eyebrow', __( 'السطر الإنجليزي', 'parole' ) );
	$add( 'parole_campaign', 'camp_number', __( 'الرقم الكبير', 'parole' ) );
	$add( 'parole_campaign', 'camp_title', __( 'العنوان', 'parole' ) );
	$add( 'parole_campaign', 'camp_chips', __( 'الوسوم (مفصولة بفاصلة)', 'parole' ) );
	$add( 'parole_campaign', 'camp_details', __( 'نص رابط التفاصيل', 'parole' ) );
	$add( 'parole_campaign', 'camp_image', __( 'الصورة (فارغ = صورة المنتج)', 'parole' ), 'image' );

	// Easy.
	$add( 'parole_easy', 'easy_eyebrow', __( 'السطر الإنجليزي', 'parole' ) );
	$add( 'parole_easy', 'easy_title', __( 'العنوان', 'parole' ) );
	$add( 'parole_easy', 'easy_text', __( 'النص', 'parole' ), 'textarea' );
	$add( 'parole_easy', 'easy_link', __( 'نص الرابط', 'parole' ) );

	// Story.
	$add( 'parole_story', 'story_eyebrow', __( 'السطر الإنجليزي', 'parole' ) );
	$add( 'parole_story', 'story_year', __( 'الرقم المفرّغ', 'parole' ) );
	$add( 'parole_story', 'story_line_1', __( 'العنوان — السطر الأول', 'parole' ) );
	$add( 'parole_story', 'story_line_2', __( 'العنوان — السطر الثاني', 'parole' ) );
	$add( 'parole_story', 'story_p1', __( 'الفقرة الأولى', 'parole' ), 'textarea' );
	$add( 'parole_story', 'story_p2', __( 'الفقرة الثانية', 'parole' ), 'textarea' );
	$add( 'parole_story', 'story_cta', __( 'نص زر الفروع', 'parole' ) );
	$add( 'parole_story', 'story_cta_url', __( 'رابط الزر (فارغ = صفحة الفروع)', 'parole' ), 'url' );
	$add( 'parole_story', 'story_image', __( 'الصورة الرئيسية', 'parole' ), 'image' );
	$add( 'parole_story', 'story_inset', __( 'الصورة الصغيرة', 'parole' ), 'image' );
	$add( 'parole_story', 'story_caption', __( 'تعليق الصورة الصغيرة', 'parole' ) );

	// Tools & goods.
	$add( 'parole_tg', 'tg_eyebrow', __( 'السطر الإنجليزي', 'parole' ) );
	$add( 'parole_tg', 'tg_title', __( 'العنوان', 'parole' ) );
	$add( 'parole_tg', 'tg_link', __( 'نص الرابط', 'parole' ) );

	// Brand.
	$add( 'parole_brand', 'footer_tagline', __( 'سطر الفوتر', 'parole' ), 'textarea' );
	$add( 'parole_brand', 'menu_url', __( 'رابط المنيو الإلكتروني (PARŌLE Electronic Menu URL)', 'parole' ), 'url', array( 'description' => __( 'يُستخدم في القائمة الرئيسية والجوال والفوتر وصفحة الفروع والرئيسية. فارغ = إخفاء كل روابط المنيو.', 'parole' ) ) );
	$add( 'parole_brand', 'menu_in_nav', __( 'إضافة «المنيو» تلقائيًا إلى القائمة الرئيسية والفوتر', 'parole' ), 'checkbox' );
	$add( 'parole_brand', 'maps_url', __( 'رابط عام لخرائط الفروع (اختياري)', 'parole' ), 'url' );
	$add( 'parole_brand', 'newsletter', __( 'نموذج النشرة (Shortcode من إضافة القوائم البريدية)', 'parole' ), 'text', array( 'description' => __( 'مثال: [mc4wp_form id="12"] — يُخفى النموذج إذا كان الحقل فارغًا.', 'parole' ) ) );
	$add( 'parole_brand', 'copyright', __( 'سطر الحقوق ({year} = السنة)', 'parole' ) );

	// Store.
	$add( 'parole_store', 'shipping_tab', __( 'نص «الشحن والاسترجاع» في صفحة المنتج', 'parole' ), 'textarea' );
	$add( 'parole_store', 'currency_label', __( 'رمز العملة المعروض', 'parole' ), 'text', array( 'description' => __( 'مثال: SAR أو ر.س', 'parole' ) ) );
	$add( 'parole_store', 'simple_checkout', __( 'نموذج إتمام طلب مبسّط (إخفاء الشركة، الرمز البريدي اختياري)', 'parole' ), 'checkbox' );
	$add( 'parole_store', 'sa_phone', __( 'التحقق من رقم الجوال السعودي (05XXXXXXXX)', 'parole' ), 'checkbox' );
}

/**
 * @param mixed $v Value.
 */
function parole_sanitize_checkbox( $v ) {
	return (bool) $v;
}
