<?php
/**
 * Shop filters built on WooCommerce's native query vars:
 *   - category tabs  → product category archives
 *   - attribute chips → WooCommerce layered-nav params (filter_{attribute}=term)
 *   - sorting         → native ?orderby=
 * Only attributes that actually have products in the current context are shown.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Current archive base URL with the active query args we want to keep.
 *
 * @param array $drop Query args to drop.
 */
function parole_filter_base_url( $drop = array() ) {
	if ( is_product_category() || is_product_tag() || is_tax( get_object_taxonomies( 'product' ) ) ) {
		$url = get_term_link( get_queried_object() );
	} else {
		$url = parole_shop_url();
	}
	$keep = array();
	foreach ( $_GET as $k => $v ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$k = sanitize_key( $k );
		if ( in_array( $k, $drop, true ) || 'paged' === $k || 'product-page' === $k ) {
			continue;
		}
		if ( 0 === strpos( $k, 'filter_' ) || 0 === strpos( $k, 'query_type_' ) || in_array( $k, array( 'orderby', 's', 'post_type', 'min_price', 'max_price', 'rating_filter' ), true ) ) {
			$keep[ $k ] = sanitize_text_field( wp_unslash( is_array( $v ) ? implode( ',', $v ) : $v ) );
		}
	}
	return add_query_arg( $keep, is_wp_error( $url ) ? parole_shop_url() : $url );
}

/**
 * Category tabs data (top-level, non-empty categories).
 *
 * @return array<int,array{label:string,url:string,count:int,on:bool}>
 */
function parole_category_tabs() {
	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'parent'     => 0,
			'hide_empty' => true,
			'orderby'    => 'menu_order',
			'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
		)
	);
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	$current = is_product_category() ? get_queried_object() : null;
	$tabs    = array();
	foreach ( $terms as $t ) {
		$on     = $current && ( $current->term_id === $t->term_id || term_is_ancestor_of( $t, $current, 'product_cat' ) );
		$tabs[] = array(
			'label' => $t->name,
			'url'   => get_term_link( $t ),
			'count' => (int) $t->count,
			'on'    => (bool) $on,
		);
	}
	return $tabs;
}

/**
 * Attribute filter groups for the current context.
 *
 * @return array<int,array{label:string,name:string,terms:array}>
 */
function parole_attribute_filters() {
	if ( ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
		return array();
	}
	$taxes = wc_get_attribute_taxonomies();
	if ( ! $taxes ) {
		return array();
	}

	$args = array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'fields'         => 'ids',
		'posts_per_page' => 500,
		'no_found_rows'  => true,
	);
	if ( is_product_category() ) {
		$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
			array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => get_queried_object_id(),
			),
		);
	}
	$cache_key = 'parole_af_' . md5( wp_json_encode( $args ) . WC_Cache_Helper::get_transient_version( 'product' ) );
	$groups    = get_transient( $cache_key );
	if ( false === $groups ) {
		$ids    = get_posts( $args );
		$groups = array();
		if ( $ids ) {
			foreach ( $taxes as $tax ) {
				$taxonomy = wc_attribute_taxonomy_name( $tax->attribute_name );
				if ( ! taxonomy_exists( $taxonomy ) ) {
					continue;
				}
				$terms = wp_get_object_terms( $ids, $taxonomy, array( 'orderby' => 'name' ) );
				if ( is_wp_error( $terms ) || count( $terms ) < 2 ) {
					continue;
				}
				$groups[] = array(
					'label' => $tax->attribute_label,
					'name'  => $tax->attribute_name,
					'terms' => array_map(
						function ( $t ) {
							return array(
								'slug' => $t->slug,
								'name' => $t->name,
							);
						},
						$terms
					),
				);
			}
		}
		set_transient( $cache_key, $groups, DAY_IN_SECONDS );
	}

	foreach ( $groups as &$g ) {
		$param  = 'filter_' . $g['name'];
		// Same normalisation WooCommerce applies to layered-nav params (handles Arabic slugs).
		$chosen = isset( $_GET[ $param ] ) ? array_filter( array_map( 'sanitize_title', explode( ',', wp_unslash( $_GET[ $param ] ) ) ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$base   = parole_filter_base_url( array( $param, 'query_type_' . $g['name'] ) );
		$g['all'] = array(
			'url' => $base,
			'on'  => empty( $chosen ),
		);
		foreach ( $g['terms'] as &$t ) {
			$t['on']  = in_array( $t['slug'], $chosen, true );
			$t['url'] = $t['on'] ? $base : add_query_arg( $param, $t['slug'], $base );
		}
		unset( $t );
	}
	unset( $g );
	return $groups;
}

/**
 * Chips for one attribute group.
 *
 * @param array  $g     Group.
 * @param string $class Extra chip class.
 */
function parole_render_attribute_chips( $g, $class = '' ) {
	echo '<a class="chip chip--soft ' . esc_attr( $class ) . ( $g['all']['on'] ? ' is-on' : '' ) . '" href="' . esc_url( $g['all']['url'] ) . '"' . ( $g['all']['on'] ? ' aria-current="true"' : '' ) . '>' . esc_html__( 'الكل', 'parole' ) . '</a>';
	foreach ( $g['terms'] as $t ) {
		echo '<a class="chip chip--soft ' . esc_attr( $class ) . ( $t['on'] ? ' is-on' : '' ) . '" href="' . esc_url( $t['url'] ) . '" rel="nofollow"' . ( $t['on'] ? ' aria-current="true"' : '' ) . '><bdi>' . esc_html( $t['name'] ) . '</bdi></a>';
	}
}

/** Bust the attribute cache when products change. */
add_action(
	'woocommerce_delete_product_transients',
	function () {
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_parole\_af\_%' OR option_name LIKE '\_transient\_timeout\_parole\_af\_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}
);
