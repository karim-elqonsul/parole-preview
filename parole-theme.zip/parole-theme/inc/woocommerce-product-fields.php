<?php
/**
 * Admin fields: PARŌLE presentation data for products and product categories.
 * Stored as ordinary post/term meta — the store keeps working if the theme is switched.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Product fields shown in Product data → General.
 */
function parole_product_field_defs() {
	return array(
		'_parole_en'     => array( __( 'السطر الإنجليزي (مثال: Single origin)', 'parole' ), 'text', __( 'فارغ = السطر الإنجليزي للتصنيف.', 'parole' ) ),
		'_parole_origin' => array( __( 'المحصول / المنشأ (مثال: إثيوبيا · كولومبيا)', 'parole' ), 'text', __( 'فارغ = خاصية «المحصول» (pa_origin).', 'parole' ) ),
		'_parole_size'   => array( __( 'الوزن / العبوة (مثال: 250g أو 7 × 12g)', 'parole' ), 'text', __( 'فارغ = خاصية «الحجم» (pa_size).', 'parole' ) ),
		'_parole_badge'  => array( __( 'شارة البطاقة (مثال: جديد)', 'parole' ), 'text', __( 'فارغ = «تخفيض» تلقائيًا عند وجود سعر مخفّض.', 'parole' ) ),
		'_parole_brew'   => array( __( 'طريقة التحضير', 'parole' ), 'textarea', __( 'تظهر كبند مستقل في صفحة المنتج.', 'parole' ) ),
	);
}

add_action(
	'woocommerce_product_options_general_product_data',
	function () {
		echo '<div class="options_group parole-fields"><p class="form-field"><strong>PARŌLE</strong></p>';
		foreach ( parole_product_field_defs() as $key => $def ) {
			$args = array(
				'id'          => $key,
				'label'       => $def[0],
				'desc_tip'    => true,
				'description' => $def[2],
			);
			if ( 'textarea' === $def[1] ) {
				woocommerce_wp_textarea_input( $args );
			} else {
				woocommerce_wp_text_input( $args );
			}
		}
		echo '</div>';
	}
);

// WooCommerce verifies the product-edit nonce and capability before this hook fires.
add_action(
	'woocommerce_admin_process_product_object',
	function ( $product ) {
		foreach ( parole_product_field_defs() as $key => $def ) {
			if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$val = 'textarea' === $def[1] ? sanitize_textarea_field( $raw ) : sanitize_text_field( $raw );
			$product->update_meta_data( $key, $val );
		}
	}
);

/* ---------------------------------------------------------------------------
 * Product category: English eyebrow label.
 * ------------------------------------------------------------------------- */
add_action(
	'product_cat_add_form_fields',
	function () {
		wp_nonce_field( 'parole_term_en', 'parole_term_en_nonce' );
		?>
		<div class="form-field">
			<label for="parole_en"><?php esc_html_e( 'السطر الإنجليزي (PARŌLE)', 'parole' ); ?></label>
			<input type="text" name="parole_en" id="parole_en" value="" dir="ltr">
			<p><?php esc_html_e( 'يظهر فوق اسم القسم والمنتجات، مثال: Coffee beans', 'parole' ); ?></p>
		</div>
		<?php
	}
);
add_action(
	'product_cat_edit_form_fields',
	function ( $term ) {
		wp_nonce_field( 'parole_term_en', 'parole_term_en_nonce' );
		?>
		<tr class="form-field">
			<th scope="row"><label for="parole_en"><?php esc_html_e( 'السطر الإنجليزي (PARŌLE)', 'parole' ); ?></label></th>
			<td><input type="text" name="parole_en" id="parole_en" dir="ltr" value="<?php echo esc_attr( get_term_meta( $term->term_id, 'parole_en', true ) ); ?>">
			<p class="description"><?php esc_html_e( 'يظهر فوق اسم القسم والمنتجات، مثال: Coffee beans', 'parole' ); ?></p></td>
		</tr>
		<?php
	}
);

/**
 * @param int $term_id Term ID.
 */
function parole_save_term_en( $term_id ) {
	if ( ! isset( $_POST['parole_en'], $_POST['parole_term_en_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['parole_term_en_nonce'] ) ), 'parole_term_en' ) || ! current_user_can( 'manage_product_terms' ) ) {
		return;
	}
	update_term_meta( $term_id, 'parole_en', sanitize_text_field( wp_unslash( $_POST['parole_en'] ) ) );
}
add_action( 'created_product_cat', 'parole_save_term_en' );
add_action( 'edited_product_cat', 'parole_save_term_en' );
