<?php
/**
 * WooCommerce integration: presentation hooks only — no checkout/payment logic is replaced.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------------------
 * Prices: "129 SAR" (number first, Latin numerals, trimmed decimals).
 * ------------------------------------------------------------------------- */
add_filter( 'woocommerce_price_trim_zeros', '__return_true' );
add_filter(
	'woocommerce_price_format',
	function ( $format, $pos ) {
		return apply_filters( 'parole_use_price_format', true ) ? '%2$s&nbsp;%1$s' : $format;
	},
	10,
	2
);
add_filter(
	'woocommerce_currency_symbol',
	function ( $symbol, $currency ) {
		$label = trim( (string) parole_mod( 'currency_label' ) );
		return ( 'SAR' === $currency && '' !== $label ) ? $label : $symbol;
	},
	10,
	2
);

/* ---------------------------------------------------------------------------
 * Layout: the theme's templates provide wrappers; no shop sidebar.
 * ------------------------------------------------------------------------- */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

add_filter(
	'woocommerce_breadcrumb_defaults',
	function ( $d ) {
		$d['delimiter']   = parole_icon( 'caret-left', 'dir-icon breadcrumb__sep' );
		$d['wrap_before'] = '<nav class="breadcrumb" aria-label="' . esc_attr__( 'مسار التصفح', 'parole' ) . '">';
		$d['wrap_after']  = '</nav>';
		$d['home']        = __( 'الرئيسية', 'parole' );
		return $d;
	}
);

add_filter(
	'loop_shop_per_page',
	function () {
		return 12;
	}
);
add_filter(
	'woocommerce_output_related_products_args',
	function ( $args ) {
		$args['posts_per_page'] = 4;
		$args['columns']        = 4;
		return $args;
	}
);
add_filter(
	'woocommerce_upsell_display_args',
	function ( $args ) {
		$args['posts_per_page'] = 4;
		$args['columns']        = 4;
		return $args;
	}
);
add_filter(
	'woocommerce_product_related_products_heading',
	function () {
		return __( 'قد يعجبك أيضًا', 'parole' );
	}
);

/* The card template renders link, image, badge, price and button itself; loop hooks stay for plugins. */
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );

/** Sort labels (design copy). */
add_filter(
	'woocommerce_catalog_orderby',
	function ( $options ) {
		$labels = array(
			'menu_order' => __( 'المميز', 'parole' ),
			'popularity' => __( 'الأكثر مبيعًا', 'parole' ),
			'rating'     => __( 'الأعلى تقييمًا', 'parole' ),
			'date'       => __( 'الأحدث', 'parole' ),
			'price'      => __( 'السعر: الأقل', 'parole' ),
			'price-desc' => __( 'السعر: الأعلى', 'parole' ),
		);
		foreach ( $options as $key => $label ) {
			if ( isset( $labels[ $key ] ) ) {
				$options[ $key ] = $labels[ $key ];
			}
		}
		return $options;
	}
);

/* ---------------------------------------------------------------------------
 * Add-to-cart button copy on cards.
 * ------------------------------------------------------------------------- */
add_filter(
	'woocommerce_product_add_to_cart_text',
	function ( $text, $product ) {
		if ( ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			return __( 'التفاصيل', 'parole' );
		}
		if ( $product->is_type( 'simple' ) ) {
			return __( 'أضف', 'parole' );
		}
		if ( $product->is_type( 'variable' ) ) {
			return __( 'اختر', 'parole' );
		}
		return $text;
	},
	10,
	2
);
add_filter(
	'woocommerce_product_single_add_to_cart_text',
	function () {
		return __( 'أضف إلى السلة', 'parole' );
	}
);

/* ---------------------------------------------------------------------------
 * Product presentation data (card + product page).
 * ------------------------------------------------------------------------- */

/**
 * Joined attribute values for the first attribute found.
 *
 * @param WC_Product $product Product.
 * @param string[]   $names   Attribute names (with or without pa_).
 */
function parole_attr_text( $product, $names ) {
	foreach ( $names as $name ) {
		$val = $product->get_attribute( $name );
		if ( '' !== trim( (string) $val ) ) {
			return str_replace( ', ', ' · ', $val );
		}
	}
	return '';
}

/**
 * Meta lines shown on cards: English eyebrow, origin line, size line, badge.
 * Every value is product data — product fields (PARŌLE box in "General") or attributes.
 *
 * @param WC_Product $product Product.
 * @return array{en:string,origin:string,size:string,badge:string}
 */
function parole_product_info( $product ) {
	$id     = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
	$en     = (string) get_post_meta( $id, '_parole_en', true );
	$origin = (string) get_post_meta( $id, '_parole_origin', true );
	$size   = (string) get_post_meta( $id, '_parole_size', true );
	$badge  = (string) get_post_meta( $id, '_parole_badge', true );

	if ( '' === $en ) {
		$cats = wc_get_product_term_ids( $id, 'product_cat' );
		foreach ( $cats as $cid ) {
			$en = (string) get_term_meta( $cid, 'parole_en', true );
			if ( '' !== $en ) {
				break;
			}
		}
	}
	if ( '' === $origin ) {
		$origin = parole_attr_text( $product, array( 'pa_origin', 'origin' ) );
	}
	if ( '' === $size ) {
		$size = parole_attr_text( $product, array( 'pa_size', 'size', 'pa_weight' ) );
	}
	if ( '' === $badge ) {
		if ( ! $product->is_in_stock() ) {
			$badge = __( 'نفدت الكمية', 'parole' );
		} elseif ( $product->is_on_sale() ) {
			$badge = __( 'تخفيض', 'parole' );
		}
	}
	return array(
		'en'     => $en,
		'origin' => $origin,
		'size'   => $size,
		'badge'  => $badge,
	);
}

/**
 * Render a product card for an arbitrary product (homepage sections).
 *
 * @param WC_Product $product Product.
 */
function parole_render_card( $product ) {
	if ( ! $product || ! $product->is_visible() ) {
		return;
	}
	$GLOBALS['post'] = get_post( $product->get_id() ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	setup_postdata( $GLOBALS['post'] );
	$GLOBALS['product'] = $product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	wc_get_template_part( 'content', 'product' );
}

/**
 * Products of a category for homepage rails.
 *
 * @param WP_Term|null $term  Category.
 * @param int          $limit Count.
 * @return WC_Product[]
 */
function parole_category_products( $term, $limit ) {
	if ( ! $term ) {
		return array();
	}
	return wc_get_products(
		array(
			'status'     => 'publish',
			'limit'      => $limit,
			'category'   => array( $term->slug ),
			'orderby'    => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
			'visibility' => 'catalog',
		)
	);
}

/* ---------------------------------------------------------------------------
 * Single product layout (keeps every WooCommerce hook so gateway/BNPL widgets still render).
 * ------------------------------------------------------------------------- */
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
add_action( 'woocommerce_single_product_summary', 'parole_pdp_header', 4 );
add_action( 'woocommerce_single_product_summary', 'parole_pdp_bnpl', 34 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_output_product_data_tabs', 45 );

/** Eyebrow, title, origin and size. */
function parole_pdp_header() {
	global $product;
	$info = parole_product_info( $product );
	echo '<div class="pdp__head">';
	echo parole_eyebrow( $info['en'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	the_title( '<h1 class="product_title pdp__title">', '</h1>' );
	if ( $info['origin'] || $info['size'] ) {
		echo '<div class="pdp__meta">';
		if ( $info['origin'] ) {
			echo '<span class="pdp__origin">' . esc_html( $info['origin'] ) . '</span>';
		}
		if ( $info['size'] ) {
			echo '<span class="pdp__size" dir="ltr">' . esc_html( $info['size'] ) . '</span>';
		}
		echo '</div>';
	}
	echo '</div>';
}

/** "Pay now or split it with" strip — only with uploaded Tabby/Tamara logos. */
function parole_pdp_bnpl() {
	$marks = parole_payment_marks( 'paymarks paymarks--bnpl', array( 'tabby', 'tamara' ) );
	if ( ! $marks ) {
		return;
	}
	echo '<div class="bnpl-strip"><span>' . esc_html( parole_mod( 'bnpl_text' ) ) . '</span>' . $marks . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/** Product tabs → accordion items; add brewing guide + shipping copy. */
add_filter(
	'woocommerce_product_tabs',
	function ( $tabs ) {
		global $product;
		if ( isset( $tabs['description'] ) ) {
			$tabs['description']['title'] = __( 'التفاصيل', 'parole' );
		}
		if ( isset( $tabs['additional_information'] ) ) {
			$tabs['additional_information']['title'] = __( 'المواصفات', 'parole' );
		}
		$guide = $product ? (string) get_post_meta( $product->get_id(), '_parole_brew', true ) : '';
		if ( '' !== trim( $guide ) ) {
			$tabs['parole_brew'] = array(
				'title'    => __( 'طريقة التحضير', 'parole' ),
				'priority' => 15,
				'callback' => function () use ( $guide ) {
					echo wp_kses_post( wpautop( $guide ) );
				},
			);
		}
		$ship = trim( (string) parole_mod( 'shipping_tab' ) );
		if ( '' !== $ship ) {
			$tabs['parole_shipping'] = array(
				'title'    => __( 'الشحن والاسترجاع', 'parole' ),
				'priority' => 40,
				'callback' => function () use ( $ship ) {
					echo wp_kses_post( wpautop( $ship ) );
				},
			);
		}
		return $tabs;
	},
	20
);
add_filter( 'woocommerce_product_description_heading', '__return_empty_string' );
add_filter( 'woocommerce_product_additional_information_heading', '__return_empty_string' );

/** Mobile sticky add-to-cart bar on the product page. */
add_action(
	'woocommerce_after_single_product',
	function () {
		global $product;
		if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			return;
		}
		?>
		<div class="buybar mob-only" data-buybar>
			<div class="buybar__info">
				<span class="buybar__name"><?php echo esc_html( $product->get_name() ); ?></span>
				<span class="buybar__price price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
			</div>
			<button type="button" class="btn btn--navy buybar__btn" data-buybar-add><?php parole_the_icon( 'bag' ); ?><span><?php esc_html_e( 'أضف إلى السلة', 'parole' ); ?></span></button>
		</div>
		<?php
	}
);

/** Body classes for page-level styling. */
add_filter(
	'body_class',
	function ( $classes ) {
		if ( is_product() ) {
			$classes[] = 'has-buybar';
		}
		return $classes;
	}
);

/* ---------------------------------------------------------------------------
 * Order steps (cart → details & payment → confirmation), classic templates.
 * ------------------------------------------------------------------------- */

/**
 * @param int $active 1..3.
 */
function parole_steps( $active ) {
	$steps = array(
		__( 'السلة', 'parole' ),
		__( 'البيانات والدفع', 'parole' ),
		__( 'التأكيد', 'parole' ),
	);
	echo '<ol class="steps" aria-label="' . esc_attr__( 'خطوات الطلب', 'parole' ) . '">';
	foreach ( $steps as $i => $label ) {
		$n     = $i + 1;
		$state = $n <= $active ? ' is-on' : '';
		$cur   = $n === $active ? ' aria-current="step"' : '';
		echo '<li class="steps__item' . esc_attr( $state ) . '"' . $cur . '><span class="steps__n" dir="ltr">' . (int) $n . '</span>' . esc_html( $label ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	echo '</ol>';
}
