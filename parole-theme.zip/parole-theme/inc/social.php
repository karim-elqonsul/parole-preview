<?php
/**
 * Official contact channels — single source for every template.
 * Admin: Appearance → Customize → PARŌLE → "التواصل والشبكات الاجتماعية".
 *
 * Defaults verified against the official Linktree (https://linktr.ee/parolecafe) on 2026-10-21.
 * Snapchat is empty on purpose: the Linktree button points to the generic snapchat.com/web/
 * page, not a PARŌLE profile. Add the profile URL in the Customizer to show the icon.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Network definitions: key => [label, icon, default URL].
 */
function parole_social_networks() {
	return array(
		'instagram' => array( 'Instagram', 'instagram', 'https://www.instagram.com/parole_cafe/' ),
		'tiktok'    => array( 'TikTok', 'tiktok', 'https://www.tiktok.com/@parole_cafesa' ),
		'snapchat'  => array( 'Snapchat', 'snapchat', '' ),
		'whatsapp'  => array( 'WhatsApp', 'whatsapp', 'https://api.whatsapp.com/send/?phone=966501225009' ),
		'x'         => array( 'X', 'x-logo', 'https://twitter.com/parole_cafe' ),
		'facebook'  => array( 'Facebook', 'facebook', 'https://www.facebook.com/parolecafe2020/' ),
	);
}

add_filter(
	'parole_defaults_extra',
	function ( $d ) {
		foreach ( parole_social_networks() as $key => $n ) {
			$d[ 'social_' . $key ] = $n[2];
		}
		$d['social_linktree'] = 'https://linktr.ee/parolecafe';
		$d['support_phone']   = '+966 57 633 6373';
		return $d;
	}
);

/**
 * Configured networks with a URL, in display order.
 *
 * @return array<string,array{label:string,icon:string,url:string}>
 */
function parole_social_links() {
	$out = array();
	foreach ( parole_social_networks() as $key => $n ) {
		$url = esc_url( trim( (string) parole_mod( 'social_' . $key ) ) );
		if ( $url ) {
			$out[ $key ] = array(
				'label' => $n[0],
				'icon'  => $n[1],
				'url'   => $url,
			);
		}
	}
	return $out;
}

/**
 * Icon row.
 *
 * @param string $class Extra class (social--footer, social--menu).
 */
function parole_social_row( $class = '' ) {
	$links = parole_social_links();
	if ( ! $links ) {
		return '';
	}
	$html = '<ul class="social ' . esc_attr( $class ) . '" role="list">';
	foreach ( $links as $key => $l ) {
		/* translators: %s: network name */
		$label = sprintf( __( 'PARŌLE على %s', 'parole' ), $l['label'] );
		$html .= sprintf(
			'<li><a class="social__link social__link--%1$s" href="%2$s" target="_blank" rel="noopener noreferrer" aria-label="%3$s" title="%4$s">%5$s</a></li>',
			esc_attr( $key ),
			esc_url( $l['url'] ),
			esc_attr( $label . ' ' . __( '(يفتح في نافذة جديدة)', 'parole' ) ),
			esc_attr( $label ),
			parole_icon( $l['icon'] )
		);
	}
	return $html . '</ul>';
}

/**
 * Customer service phone.
 *
 * @return array{display:string,tel:string}|null
 */
function parole_support_phone() {
	$display = trim( (string) parole_mod( 'support_phone' ) );
	if ( '' === $display ) {
		return null;
	}
	return array(
		'display' => $display,
		'tel'     => preg_replace( '/[^\d+]/', '', $display ),
	);
}

/**
 * WhatsApp URL (separate channel from the customer-service phone).
 */
function parole_whatsapp_url() {
	return esc_url( trim( (string) parole_mod( 'social_whatsapp' ) ) );
}

add_action(
	'customize_register',
	function ( $wp_customize ) {
		$wp_customize->add_section(
			'parole_social',
			array(
				'title'       => __( 'التواصل والشبكات الاجتماعية', 'parole' ),
				'panel'       => 'parole',
				'priority'    => 95,
				'description' => __( 'رابط فارغ = إخفاء الأيقونة في كل الموقع.', 'parole' ),
			)
		);
		$d = parole_defaults();
		$wp_customize->add_setting( 'parole_support_phone', array( 'default' => $d['support_phone'], 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp_customize->add_control( 'parole_support_phone', array( 'label' => __( 'هاتف خدمة العملاء (PARŌLE Customer Service Phone)', 'parole' ), 'section' => 'parole_social', 'type' => 'tel' ) );
		foreach ( parole_social_networks() as $key => $n ) {
			$wp_customize->add_setting( 'parole_social_' . $key, array( 'default' => $d[ 'social_' . $key ], 'sanitize_callback' => 'esc_url_raw' ) );
			/* translators: %s: network */
			$wp_customize->add_control( 'parole_social_' . $key, array( 'label' => sprintf( __( 'رابط %s', 'parole' ), $n[0] ), 'section' => 'parole_social', 'type' => 'url' ) );
		}
		$wp_customize->add_setting( 'parole_social_linktree', array( 'default' => $d['social_linktree'], 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control( 'parole_social_linktree', array( 'label' => __( 'رابط Linktree («كل الروابط»)', 'parole' ), 'section' => 'parole_social', 'type' => 'url' ) );
	},
	20
);

/**
 * Help-page channels card: customer-service call (primary), WhatsApp, then social profiles
 * with labels, and a small "all links" (Linktree) link.
 */
function parole_contact_channels() {
	$phone  = parole_support_phone();
	$wa     = parole_whatsapp_url();
	$links  = parole_social_links();
	$tree   = esc_url( trim( (string) parole_mod( 'social_linktree' ) ) );
	$newtab = '<span class="screen-reader-text"> ' . esc_html__( '(يفتح في نافذة جديدة)', 'parole' ) . '</span>';
	unset( $links['whatsapp'] );
	if ( ! $phone && ! $wa && ! $links ) {
		return '';
	}
	ob_start();
	?>
	<section class="contact-card channels" aria-labelledby="channels-title">
		<h2 class="contact-card__title" id="channels-title"><?php esc_html_e( 'تابعنا وتواصل معنا', 'parole' ); ?></h2>
		<?php if ( $phone ) : ?>
			<div class="channels__primary">
				<span class="channels__label"><?php esc_html_e( 'خدمة العملاء', 'parole' ); ?></span>
				<a class="channels__tel" href="<?php echo esc_url( 'tel:' . $phone['tel'] ); ?>" dir="ltr"><?php echo esc_html( $phone['display'] ); ?></a>
				<a class="btn btn--navy btn--block" href="<?php echo esc_url( 'tel:' . $phone['tel'] ); ?>"><?php parole_the_icon( 'phone' ); ?><?php esc_html_e( 'اتصل بخدمة العملاء', 'parole' ); ?></a>
			</div>
		<?php endif; ?>
		<?php if ( $wa ) : ?>
			<a class="btn btn--soft btn--block channels__wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener noreferrer"><?php parole_the_icon( 'whatsapp' ); ?><?php esc_html_e( 'تواصل معنا عبر واتساب', 'parole' ); ?><?php echo $newtab; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
		<?php endif; ?>
		<?php if ( $links ) : ?>
			<ul class="channels__list" role="list">
				<?php foreach ( $links as $key => $l ) : ?>
					<li><a class="channels__item" href="<?php echo esc_url( $l['url'] ); ?>" target="_blank" rel="noopener noreferrer"><span class="channels__icon"><?php parole_the_icon( $l['icon'] ); ?></span><span dir="ltr"><?php echo esc_html( $l['label'] ); ?></span><?php echo $newtab; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php if ( $tree ) : ?>
			<a class="channels__all" href="<?php echo esc_url( $tree ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'كل الروابط', 'parole' ); ?><?php echo $newtab; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php parole_the_icon( 'external', 'ext-icon' ); ?></a>
		<?php endif; ?>
	</section>
	<?php
	return ob_get_clean();
}
