<?php
/**
 * Block patterns for the content pages (About values, FAQ). Insert from the editor's
 * pattern inserter → "PARŌLE". Content stays fully editable in Gutenberg.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	function () {
		register_block_pattern_category( 'parole', array( 'label' => 'PARŌLE' ) );

		$values = array(
			array( 'البساطة', 'تجربة بلا تعقيد — من الطلب إلى الفنجان.' ),
			array( 'الجودة', 'مكوّنات مختارة بعناية.' ),
			array( 'الأصالة', 'ارتباط حقيقي بثقافة القهوة.' ),
			array( 'القرب', 'علامة قريبة من الناس وسهلة التواصل.' ),
		);
		$cols = '';
		foreach ( $values as $v ) {
			$cols .= '<!-- wp:column {"className":"value-card"} --><div class="wp-block-column value-card"><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">' . esc_html( $v[0] ) . '</h3><!-- /wp:heading --><!-- wp:paragraph --><p>' . esc_html( $v[1] ) . '</p><!-- /wp:paragraph --></div><!-- /wp:column -->';
		}
		register_block_pattern(
			'parole/values',
			array(
				'title'      => __( 'قيم بارولي (٤ أعمدة)', 'parole' ),
				'categories' => array( 'parole' ),
				'content'    => '<!-- wp:columns {"className":"values-grid"} --><div class="wp-block-columns values-grid">' . $cols . '</div><!-- /wp:columns -->',
			)
		);

		$faqs = array(
			array( 'كيف أطلب من المتجر؟', 'اختر المنتج، أضفه إلى السلة، ثم أكمل بياناتك واختر طريقة الاستلام والدفع.' ),
			array( 'ما طرق الدفع المتاحة؟', 'تظهر طرق الدفع المفعّلة في خطوة إتمام الطلب.' ),
			array( 'هل يتوفر التوصيل أو الاستلام من الفرع؟', 'نعم، تختار بين التوصيل إلى عنوانك أو الاستلام من الفرع في خطوة إتمام الطلب، وتظهر التفاصيل قبل الدفع.' ),
			array( 'هل يمكنني استرجاع طلبي؟', 'تواصل معنا عبر النموذج أو إنستغرام مع رقم الطلب، ونوضح لك الخطوات حسب حالة المنتج وسياسة بارولي المعتمدة.' ),
			array( 'كيف أختار الطحن المناسب؟', 'اختر «حبوب كاملة» إذا عندك مطحنة، و«طحن للتقطير» لأدوات V60 والكيمكس، و«طحن للإسبريسو» لمكائن الإسبريسو.' ),
		);
		$items = '';
		foreach ( $faqs as $f ) {
			$items .= '<!-- wp:details {"className":"faq"} --><details class="wp-block-details faq"><summary>' . esc_html( $f[0] ) . '</summary><!-- wp:paragraph --><p>' . esc_html( $f[1] ) . '</p><!-- /wp:paragraph --></details><!-- /wp:details -->';
		}
		register_block_pattern(
			'parole/faq',
			array(
				'title'      => __( 'الأسئلة الشائعة (أكورديون)', 'parole' ),
				'categories' => array( 'parole' ),
				'content'    => $items,
			)
		);
	}
);
