<?php
/**
 * Brand fonts.
 *
 * - Ysabeau Office (Latin, SIL OFL) and Tajawal (Arabic fallback, SIL OFL) are bundled.
 * - Dahab Arabic ITF is a commercial font. It is NOT bundled. Once a webfont licence is
 *   confirmed, upload the .woff2 files to  wp-content/uploads/parole-fonts/  (survives theme
 *   updates) or to  parole-theme/assets/fonts/dahab/ . The theme detects them automatically
 *   and puts Dahab first in the Arabic stack; otherwise Tajawal is used.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Dahab weights → expected file names.
 */
function parole_dahab_weights() {
	return array(
		300 => 'DahabArabicITF-Light',
		400 => 'DahabArabicITF-Regular',
		500 => 'DahabArabicITF-Medium',
		700 => 'DahabArabicITF-Bold',
		800 => 'DahabArabicITF-ExtraBold',
		900 => 'DahabArabicITF-Black',
	);
}

/**
 * Locate licensed Dahab files. Returns weight => URL (woff2 preferred, otf accepted).
 *
 * @return array<int,string>
 */
function parole_dahab_sources() {
	static $found = null;
	if ( null !== $found ) {
		return $found;
	}
	$found   = array();
	$uploads = wp_get_upload_dir();
	$bases   = array(
		array( trailingslashit( $uploads['basedir'] ) . 'parole-fonts/', trailingslashit( $uploads['baseurl'] ) . 'parole-fonts/' ),
		array( PAROLE_DIR . '/assets/fonts/dahab/', PAROLE_URI . '/assets/fonts/dahab/' ),
	);
	foreach ( parole_dahab_weights() as $weight => $file ) {
		foreach ( $bases as $base ) {
			foreach ( array( 'woff2', 'woff', 'otf' ) as $ext ) {
				if ( file_exists( $base[0] . $file . '.' . $ext ) ) {
					$found[ $weight ] = array( set_url_scheme( $base[1] . $file . '.' . $ext ), $ext );
					continue 3;
				}
			}
		}
	}
	return $found;
}

/**
 * @font-face rules for every brand face.
 */
function parole_font_face_css() {
	$uri = PAROLE_URI . '/assets/fonts/';
	$css = '';

	foreach ( array( 400, 500, 600, 700 ) as $w ) {
		$css .= "@font-face{font-family:'Ysabeau Office';font-style:normal;font-weight:{$w};font-display:swap;src:url('{$uri}ysabeau-office-latin-{$w}.woff2') format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD,U+0100-017F;}";
	}
	foreach ( array( 400, 500, 700 ) as $w ) {
		$css .= "@font-face{font-family:'Tajawal';font-style:normal;font-weight:{$w};font-display:swap;src:url('{$uri}tajawal-arabic-{$w}.woff2') format('woff2');unicode-range:U+0600-06FF,U+0750-077F,U+0870-088E,U+0890-0891,U+0897-08E1,U+08E3-08FF,U+200C-200E,U+2010-2011,U+204F,U+2E41,U+FB50-FDFF,U+FE70-FE74,U+FE76-FEFC,U+102E0-102FB,U+10E60-10E7E,U+10EC2-10EC4,U+10EFC-10EFF,U+1EE00-1EEFF;}";
	}
	$formats = array(
		'woff2' => 'woff2',
		'woff'  => 'woff',
		'otf'   => 'opentype',
	);
	foreach ( parole_dahab_sources() as $w => $src ) {
		$css .= sprintf(
			"@font-face{font-family:'Dahab Arabic ITF';font-style:normal;font-weight:%d;font-display:swap;src:url('%s') format('%s');}",
			(int) $w,
			esc_url_raw( $src[0] ),
			$formats[ $src[1] ]
		);
	}
	return $css;
}

/**
 * Preload the two faces needed above the fold.
 */
add_action(
	'wp_head',
	function () {
		$dahab = parole_dahab_sources();
		$urls  = array();
		if ( isset( $dahab[700] ) && 'woff2' === $dahab[700][1] ) {
			$urls[] = $dahab[700][0];
		} else {
			$urls[] = PAROLE_URI . '/assets/fonts/tajawal-arabic-700.woff2';
		}
		$urls[] = PAROLE_URI . '/assets/fonts/ysabeau-office-latin-600.woff2';
		foreach ( $urls as $u ) {
			printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $u ) );
		}
	},
	2
);
