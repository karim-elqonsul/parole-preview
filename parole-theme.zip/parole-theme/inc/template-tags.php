<?php
/**
 * Small presentational helpers shared by templates.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/**
 * Brand logo: the Customizer "Site Logo" if set, otherwise the official supplied artwork.
 *
 * @param string $class CSS class.
 */
function parole_logo( $class = 'site-logo' ) {
	$id  = (int) get_theme_mod( 'custom_logo' );
	$alt = __( 'بارولي PARŌLE', 'parole' );
	if ( $id ) {
		return wp_get_attachment_image(
			$id,
			'full',
			false,
			array(
				'class'   => $class,
				'alt'     => $alt,
				'loading' => 'eager',
			)
		);
	}
	return sprintf(
		'<img class="%s" src="%s" width="797" height="372" alt="%s" decoding="async">',
		esc_attr( $class ),
		esc_url( PAROLE_URI . '/assets/images/parole-logo-official.png' ),
		esc_attr( $alt )
	);
}

/**
 * <picture> for a bundled default image (webp + jpg, two widths).
 *
 * @param string $name  Base name in assets/images (without -{w}.ext).
 * @param string $alt   Alt text.
 * @param string $sizes sizes attribute.
 * @param array  $attr  Extra img attributes.
 */
function parole_default_picture( $name, $alt, $sizes = '100vw', $attr = array() ) {
	$widths = 'hero-stone' === $name ? array( 800, 1586 ) : array( 640, 1200 );
	$dims   = 'hero-stone' === $name ? array( 1586, 992 ) : array( 1200, 900 );
	$base   = PAROLE_URI . '/assets/images/' . $name . '-';
	$set    = function ( $ext ) use ( $widths, $base ) {
		return implode(
			', ',
			array_map(
				function ( $w ) use ( $base, $ext ) {
					return esc_url( $base . $w . '.' . $ext ) . ' ' . $w . 'w';
				},
				$widths
			)
		);
	};
	$attr = wp_parse_args(
		$attr,
		array(
			'loading'  => 'lazy',
			'decoding' => 'async',
			'class'    => '',
		)
	);
	$extra = '';
	foreach ( $attr as $k => $v ) {
		if ( '' !== $v ) {
			$extra .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
		}
	}
	return sprintf(
		'<picture><source type="image/webp" srcset="%1$s" sizes="%3$s"><img src="%4$s" srcset="%2$s" sizes="%3$s" width="%5$d" height="%6$d" alt="%7$s"%8$s></picture>',
		$set( 'webp' ),
		$set( 'jpg' ),
		esc_attr( $sizes ),
		esc_url( $base . $widths[1] . '.jpg' ),
		$dims[0],
		$dims[1],
		esc_attr( $alt ),
		$extra
	);
}

/**
 * Uploaded image (attachment ID) or bundled default.
 *
 * @param int    $id       Attachment ID (0 = use default).
 * @param string $fallback Bundled image name.
 * @param string $alt      Alt text.
 * @param string $sizes    sizes attribute.
 * @param array  $attr     Extra attributes.
 * @param string $size     WP image size for uploads.
 */
function parole_image( $id, $fallback, $alt, $sizes = '100vw', $attr = array(), $size = 'large' ) {
	if ( $id && wp_attachment_is_image( $id ) ) {
		return wp_get_attachment_image( $id, $size, false, array_merge( array( 'sizes' => $sizes, 'alt' => $alt ), $attr ) );
	}
	return $fallback ? parole_default_picture( $fallback, $alt, $sizes, $attr ) : '';
}

/**
 * Default slugs for the five design categories (created by the store owner / sample data).
 */
function parole_category_slugs() {
	return array(
		'beans'   => 'coffee-beans',
		'bundles' => 'bundles-gifts',
		'easy'    => 'easy-brew',
		'tools'   => 'brewing-tools',
		'goods'   => 'parole-goods',
	);
}

/**
 * Category assigned to a design role (Customizer choice, else the default slug).
 *
 * @param string $role beans|bundles|easy|tools|goods.
 * @return WP_Term|null
 */
function parole_category( $role ) {
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return null;
	}
	$id = absint( parole_mod( 'cat_' . $role ) );
	if ( $id ) {
		$t = get_term( $id, 'product_cat' );
		if ( $t instanceof WP_Term ) {
			return $t;
		}
	}
	$slugs = parole_category_slugs();
	$t     = isset( $slugs[ $role ] ) ? get_term_by( 'slug', $slugs[ $role ], 'product_cat' ) : false;
	return $t instanceof WP_Term ? $t : null;
}

/**
 * English eyebrow label stored on a product category (term meta, editable on the category screen).
 *
 * @param WP_Term|null $term Term.
 */
function parole_term_en( $term ) {
	return $term ? (string) get_term_meta( $term->term_id, 'parole_en', true ) : '';
}

/**
 * Small Latin eyebrow.
 *
 * @param string $text  Text.
 * @param string $class Extra class.
 */
function parole_eyebrow( $text, $class = '' ) {
	if ( '' === trim( (string) $text ) ) {
		return '';
	}
	return '<span class="eyebrow ' . esc_attr( $class ) . '" dir="ltr">' . esc_html( $text ) . '</span>';
}

/**
 * Section header: eyebrow + title + optional "see all" link.
 *
 * @param string $eyebrow Eyebrow.
 * @param string $title   Title.
 * @param string $url     Link URL.
 * @param string $label   Link label.
 */
function parole_section_head( $eyebrow, $title, $url = '', $label = '' ) {
	?>
	<div class="section-head">
		<div class="section-head__titles">
			<?php echo parole_eyebrow( $eyebrow ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<h2 class="section-title"><?php echo esc_html( $title ); ?></h2>
		</div>
		<?php if ( $url && $label ) : ?>
			<a class="link-arrow" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $label ); ?><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></a>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * URL of the first published page using a template file, or a fallback.
 *
 * @param string $template e.g. page-templates/branches.php.
 * @param string $fallback Fallback URL.
 */
function parole_template_url( $template, $fallback = '' ) {
	$pages = get_pages(
		array(
			'meta_key'   => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value' => $template, // phpcs:ignore WordPress.DB.SlowDBQuery
			'number'     => 1,
		)
	);
	return $pages ? get_permalink( $pages[0] ) : $fallback;
}

/**
 * Payment-logo strip (only uploaded logos; hidden when none).
 *
 * @param string        $class Wrapper class.
 * @param string[]|null $only  Slots.
 */
function parole_payment_marks( $class = 'paymarks', $only = null ) {
	$logos = parole_payment_logos( $only );
	if ( ! $logos ) {
		return '';
	}
	$html = '<ul class="' . esc_attr( $class ) . '" role="list">';
	foreach ( $logos as $l ) {
		$html .= '<li class="paymark paymark--' . esc_attr( $l['slot'] ) . '">' . wp_get_attachment_image(
			$l['id'],
			'medium',
			false,
			array(
				'alt'     => $l['label'],
				'title'   => $l['label'],
				'loading' => 'lazy',
			)
		) . '</li>';
	}
	return $html . '</ul>';
}

/**
 * Breadcrumb for plain pages (WooCommerce pages use wc breadcrumbs).
 *
 * @param string $current Current label.
 */
function parole_page_breadcrumb( $current ) {
	?>
	<nav class="breadcrumb" aria-label="<?php esc_attr_e( 'مسار التصفح', 'parole' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'الرئيسية', 'parole' ); ?></a>
		<?php parole_the_icon( 'caret-left', 'dir-icon breadcrumb__sep' ); ?>
		<span aria-current="page"><?php echo esc_html( $current ); ?></span>
	</nav>
	<?php
}

/**
 * Shop URL (WooCommerce shop page or home).
 */
function parole_shop_url() {
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}

/**
 * Link to a design category role, falling back to the shop.
 *
 * @param string $role Role.
 */
function parole_category_url( $role ) {
	$t = parole_category( $role );
	if ( $t ) {
		$l = get_term_link( $t );
		if ( ! is_wp_error( $l ) ) {
			return $l;
		}
	}
	return parole_shop_url();
}

/**
 * Primary menu fallback: the design's four shop sections (only categories that exist).
 */
function parole_menu_fallback( $args = array() ) {
	$after = is_array( $args ) && ! empty( $args['link_after'] ) ? $args['link_after'] : '';
	$items = array();
	foreach ( array( 'beans', 'easy', 'tools', 'goods' ) as $role ) {
		$t = parole_category( $role );
		if ( $t ) {
			$current = is_tax( 'product_cat', $t->term_id ) ? ' current-menu-item' : '';
			$items[] = '<li class="menu-item' . $current . '"><a href="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . $after . '</a></li>';
		}
	}
	if ( ! $items && function_exists( 'wc_get_page_permalink' ) ) {
		$items[] = '<li class="menu-item"><a href="' . esc_url( parole_shop_url() ) . '">' . esc_html__( 'المتجر', 'parole' ) . '</a></li>';
	}
	if ( parole_mod( 'menu_in_nav' ) && function_exists( 'parole_menu_link' ) && parole_menu_url() ) {
		$items[] = '<li class="menu-item parole-emenu menu-item--external">' . str_replace( '</a>', $after . '</a>', parole_menu_link( __( 'المنيو', 'parole' ) ) ) . '</li>';
	}
	if ( $items ) {
		echo '<ul class="primary-nav__list">' . implode( '', $items ) . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

/**
 * Footer column: assigned menu (menu name = column title) or a sensible fallback built from real pages.
 *
 * @param string $location Menu location.
 */
function parole_footer_column( $location ) {
	$locations = get_nav_menu_locations();
	if ( ! empty( $locations[ $location ] ) ) {
		$menu = wp_get_nav_menu_object( $locations[ $location ] );
		if ( $menu ) {
			echo '<nav class="footer-col" aria-label="' . esc_attr( $menu->name ) . '"><span class="footer-col__title">' . esc_html( $menu->name ) . '</span>';
			wp_nav_menu(
				array(
					'theme_location' => $location,
					'container'      => false,
					'menu_class'     => 'footer-col__list',
					'depth'          => 1,
				)
			);
			echo '</nav>';
			return;
		}
	}

	$title = '';
	$links = array();
	if ( 'footer-1' === $location ) {
		$title = __( 'المتجر', 'parole' );
		foreach ( array( 'beans', 'easy', 'tools', 'goods', 'bundles' ) as $role ) {
			$t = parole_category( $role );
			if ( $t ) {
				$links[] = array( get_term_link( $t ), $t->name );
			}
		}
	} elseif ( 'footer-2' === $location ) {
		$title = __( 'المساعدة', 'parole' );
		$help  = parole_template_url( 'page-templates/help.php' );
		if ( $help ) {
			$links[] = array( $help, __( 'الأسئلة الشائعة', 'parole' ) );
			$links[] = array( $help . '#contact', __( 'تواصل معنا', 'parole' ) );
		}
		$policy = (int) get_option( 'woocommerce_refund_returns_page_id' );
		if ( $policy && 'publish' === get_post_status( $policy ) ) {
			$links[] = array( get_permalink( $policy ), __( 'الاسترجاع', 'parole' ) );
		}
		$privacy = get_privacy_policy_url();
		if ( $privacy ) {
			$links[] = array( $privacy, __( 'سياسة الخصوصية', 'parole' ) );
		}
	} else {
		$title = __( 'بارولي', 'parole' );
		$about = parole_template_url( 'page-templates/about.php' );
		$br    = parole_template_url( 'page-templates/branches.php' );
		if ( $about ) {
			$links[] = array( $about, __( 'قصتنا', 'parole' ) );
		}
		if ( $br ) {
			$links[] = array( $br, __( 'الفروع', 'parole' ) );
		}
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			$links[] = array( wc_get_page_permalink( 'myaccount' ), __( 'حسابي', 'parole' ) );
		}
	}
	if ( ! $links ) {
		return;
	}
	echo '<nav class="footer-col" aria-label="' . esc_attr( $title ) . '"><span class="footer-col__title">' . esc_html( $title ) . '</span><ul class="footer-col__list">';
	foreach ( $links as $l ) {
		echo '<li><a href="' . esc_url( $l[0] ) . '">' . esc_html( $l[1] ) . '</a></li>';
	}
	if ( 'footer-3' === $location && parole_mod( 'menu_in_nav' ) && function_exists( 'parole_menu_link' ) ) {
		$menu_link = parole_menu_link( __( 'المنيو الإلكتروني', 'parole' ) );
		if ( $menu_link ) {
			echo '<li class="parole-emenu">' . $menu_link . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
	echo '</ul></nav>';
}
