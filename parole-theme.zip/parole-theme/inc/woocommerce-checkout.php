<?php
/**
 * Checkout presentation. The WooCommerce checkout (fields, shipping incl. Local Pickup,
 * payment gateways, order processing) is untouched — only labels/layout are adjusted.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

/* Step indicator on the classic cart / checkout / thank-you templates. */
add_action(
	'woocommerce_before_cart',
	function () {
		parole_steps( 1 );
	},
	5
);
add_action(
	'woocommerce_before_checkout_form',
	function () {
		parole_steps( 2 );
	},
	1
);
add_action(
	'woocommerce_before_thankyou',
	function () {
		parole_steps( 3 );
	},
	1
);

/**
 * Optional simplified field set for Saudi checkout (Customizer → PARŌLE → Store).
 */
add_filter(
	'woocommerce_checkout_fields',
	function ( $fields ) {
		if ( isset( $fields['billing']['billing_phone'] ) ) {
			$fields['billing']['billing_phone']['placeholder'] = '05X XXX XXXX';
			$fields['billing']['billing_phone']['priority']    = 25;
		}
		if ( ! parole_mod( 'simple_checkout' ) ) {
			return $fields;
		}
		foreach ( array( 'billing', 'shipping' ) as $group ) {
			unset( $fields[ $group ][ $group . '_company' ] );
			if ( isset( $fields[ $group ][ $group . '_postcode' ] ) ) {
				$fields[ $group ][ $group . '_postcode' ]['required'] = false;
			}
		}
		return $fields;
	},
	20
);

/* Postcode optional in Saudi Arabia when simplified checkout is on (country locale is what WC validates). */
add_filter(
	'woocommerce_get_country_locale',
	function ( $locale ) {
		if ( parole_mod( 'simple_checkout' ) ) {
			$locale['SA']['postcode']['required'] = false;
			$locale['SA']['company']['hidden']    = true;
		}
		return $locale;
	}
);

/**
 * Saudi mobile validation (05XXXXXXXX / +9665XXXXXXXX) when billing country is SA.
 */
add_action(
	'woocommerce_after_checkout_validation',
	function ( $data, $errors ) {
		if ( ! parole_mod( 'sa_phone' ) || empty( $data['billing_phone'] ) || ( isset( $data['billing_country'] ) && 'SA' !== $data['billing_country'] ) ) {
			return;
		}
		$digits = preg_replace( '/\D+/', '', (string) $data['billing_phone'] );
		$digits = preg_replace( '/^(00966|966)/', '0', $digits );
		if ( ! preg_match( '/^05\d{8}$/', $digits ) ) {
			$errors->add( 'billing_phone_validation', __( 'رقم الجوال: رقم سعودي من ١٠ أرقام يبدأ بـ 05', 'parole' ), array( 'id' => 'billing_phone' ) );
		}
	},
	10,
	2
);

/* Order review heading + mobile summary toggle (pure presentation). */
add_action(
	'woocommerce_checkout_before_order_review_heading',
	function () {
		if ( ! WC()->cart ) {
			return;
		}
		printf(
			'<button type="button" class="summary-toggle mob-only" aria-expanded="false" aria-controls="order_review" data-summary-toggle><span>%1$s %2$s</span><span class="summary-toggle__total">%3$s</span></button>',
			parole_icon( 'receipt' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			/* translators: %d: items */
			esc_html( sprintf( __( 'ملخّص الطلب (%d)', 'parole' ), WC()->cart->get_cart_contents_count() ) ),
			wp_kses_post( WC()->cart->get_total() )
		);
	}
);
add_filter(
	'woocommerce_order_button_text',
	function () {
		return __( 'تأكيد الطلب والدفع', 'parole' );
	}
);

/* Secure-connection note above the payment methods. */
add_action(
	'woocommerce_review_order_before_payment',
	function () {
		echo '<div class="pay-head"><h3 class="pay-head__title">' . esc_html__( 'الدفع', 'parole' ) . '</h3><span class="pay-head__secure">' . parole_icon( 'lock' ) . esc_html__( 'اتصال مشفّر', 'parole' ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
);
