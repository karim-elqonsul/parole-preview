<?php
/**
 * First activation: create the three content pages from the approved design (only if a page
 * using the template does not exist yet). Nothing is overwritten on re-activation.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;

add_action( 'after_switch_theme', 'parole_create_pages', 20 );
function parole_create_pages() {
	// Runs once, on the first request after an administrator switched to this theme.
	if ( ! did_action( 'init' ) && ! doing_action( 'init' ) ) {
		return;
	}
	$registry = WP_Block_Patterns_Registry::get_instance();
	$pattern  = function ( $name ) use ( $registry ) {
		$p = $registry->get_registered( $name );
		return $p ? $p['content'] : '';
	};

	$pages = array(
		'page-templates/about.php'    => array(
			'title'   => 'قصتنا',
			'slug'    => 'about',
			'excerpt' => 'بارولي من كلمة «الكلام» — لأن القهوة دائمًا تجمع الناس. بدأنا من إيمان بسيط: القهوة ليست مجرد مشروب، بل طقس يومي ومساحة هادئة وسط زحمة اليوم.',
			'content' => $pattern( 'parole/values' ),
		),
		'page-templates/branches.php' => array(
			'title'   => 'الفروع',
			'slug'    => 'branches',
			'excerpt' => '',
			'content' => '',
		),
		'page-templates/help.php'     => array(
			'title'   => 'المساعدة',
			'slug'    => 'help',
			'excerpt' => '',
			'content' => $pattern( 'parole/faq' ),
		),
	);

	foreach ( $pages as $template => $p ) {
		if ( parole_template_url( $template ) ) {
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $p['title'],
				'post_name'    => $p['slug'],
				'post_excerpt' => $p['excerpt'],
				'post_content' => $p['content'],
			),
			true
		);
		if ( ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_wp_page_template', $template );
		}
	}
}
