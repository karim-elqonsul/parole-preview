<?php
/**
 * Site header.
 *
 * @package Parole
 */

defined( 'ABSPATH' ) || exit;
$parole_has_wc = class_exists( 'WooCommerce' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<meta name="theme-color" content="#FCF8F2">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e( 'تخطَّ إلى المحتوى', 'parole' ); ?></a>

<div class="page">
<header class="site-header" data-header>
	<div class="wrap site-header__bar">
		<button type="button" class="icon-btn mob-only" data-open="menu" aria-controls="mobile-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'القائمة', 'parole' ); ?>"><?php parole_the_icon( 'list' ); ?></button>

		<a class="site-header__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php esc_attr_e( 'بارولي — الرئيسية', 'parole' ); ?>"><?php echo parole_logo( 'site-logo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>

		<nav class="primary-nav desk-only" aria-label="<?php esc_attr_e( 'الأقسام', 'parole' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'primary-nav__list',
					'depth'          => 1,
					'fallback_cb'    => 'parole_menu_fallback',
				)
			);
			?>
		</nav>

		<div class="site-header__actions">
			<a class="search-btn" href="<?php echo esc_url( $parole_has_wc ? add_query_arg( array( 's' => '', 'post_type' => 'product' ), home_url( '/' ) ) : home_url( '/?s=' ) ); ?>" data-open="search" role="button" aria-controls="search-overlay" aria-expanded="false" aria-label="<?php esc_attr_e( 'بحث', 'parole' ); ?>">
				<?php parole_the_icon( 'search' ); ?><span class="desk-only search-btn__label"><?php esc_html_e( 'بحث', 'parole' ); ?></span>
			</a>
			<?php if ( $parole_has_wc ) : ?>
				<a class="icon-btn desk-only" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" aria-label="<?php esc_attr_e( 'حسابي', 'parole' ); ?>"><?php parole_the_icon( 'user' ); ?></a>
				<?php parole_cart_button(); ?>
			<?php endif; ?>
		</div>
	</div>
</header>
