<?php
/**
 * Shop / category / product-search archive (overrides woocommerce/templates/archive-product.php).
 *
 * @package Parole
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header();

remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

global $wp_query;
$parole_total   = (int) $wp_query->found_posts;
$parole_tabs    = parole_category_tabs();
$parole_filters = parole_attribute_filters();
$parole_title   = is_search()
	/* translators: %s: search query */
	? sprintf( __( 'نتائج البحث: «%s»', 'parole' ), get_search_query() )
	: woocommerce_page_title( false );
?>
<main id="main" class="wrap page-pad shop">
	<?php do_action( 'woocommerce_before_main_content' ); ?>

	<header class="shop__head">
		<div class="shop__titles">
			<h1 class="page-title"><?php echo esc_html( $parole_title ); ?></h1>
			<span class="shop__count">
				<?php
				/* translators: %d: number of products */
				echo esc_html( sprintf( _n( '%d منتج', '%d منتج', $parole_total, 'parole' ), $parole_total ) );
				?>
			</span>
		</div>
		<div class="shop__tools">
			<?php if ( $parole_tabs || $parole_filters ) : ?>
				<button type="button" class="btn btn--soft btn--sm mob-only" data-open="filters" aria-controls="filter-sheet" aria-expanded="false"><?php parole_the_icon( 'faders' ); ?><?php esc_html_e( 'تصفية', 'parole' ); ?></button>
			<?php endif; ?>
			<?php if ( $parole_total ) : ?>
				<?php woocommerce_catalog_ordering(); ?>
			<?php endif; ?>
		</div>
	</header>

	<?php
	$parole_desc = is_product_category() ? term_description() : '';
	if ( $parole_desc && ! is_paged() ) :
		?>
		<div class="shop__desc"><?php echo wp_kses_post( $parole_desc ); ?></div>
	<?php endif; ?>

	<?php if ( $parole_tabs || $parole_filters ) : ?>
		<div class="filterbar desk-only">
			<a class="chip<?php echo ( is_shop() && ! is_search() ) ? ' is-on' : ''; ?>" href="<?php echo esc_url( parole_shop_url() ); ?>"<?php echo ( is_shop() && ! is_search() ) ? ' aria-current="page"' : ''; ?>><?php esc_html_e( 'الكل', 'parole' ); ?></a>
			<?php foreach ( $parole_tabs as $parole_t ) : ?>
				<a class="chip<?php echo $parole_t['on'] ? ' is-on' : ''; ?>" href="<?php echo esc_url( $parole_t['url'] ); ?>"<?php echo $parole_t['on'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $parole_t['label'] ); ?> <span class="chip__count" dir="ltr"><?php echo (int) $parole_t['count']; ?></span></a>
			<?php endforeach; ?>
			<?php foreach ( $parole_filters as $parole_g ) : ?>
				<span class="filterbar__sep" aria-hidden="true"></span>
				<div class="filterbar__group" role="group" aria-label="<?php echo esc_attr( $parole_g['label'] ); ?>">
					<span class="filterbar__label" aria-hidden="true"><?php echo esc_html( $parole_g['label'] ); ?></span>
					<?php parole_render_attribute_chips( $parole_g ); ?>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php
	if ( woocommerce_product_loop() ) {
		do_action( 'woocommerce_before_shop_loop' );
		woocommerce_product_loop_start();
		if ( wc_get_loop_prop( 'total' ) ) {
			while ( have_posts() ) {
				the_post();
				do_action( 'woocommerce_shop_loop' );
				wc_get_template_part( 'content', 'product' );
			}
		}
		woocommerce_product_loop_end();
		do_action( 'woocommerce_after_shop_loop' );
	} else {
		do_action( 'woocommerce_no_products_found' );
	}
	do_action( 'woocommerce_after_main_content' );
	?>
</main>

<?php if ( $parole_tabs || $parole_filters ) : ?>
<div class="overlay overlay--sheet" id="filter-sheet" data-overlay="filters" hidden>
	<div class="overlay__backdrop" data-close></div>
	<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="filter-sheet-title">
		<span class="sheet__grip" aria-hidden="true"></span>
		<h2 class="sheet__title" id="filter-sheet-title"><?php esc_html_e( 'تصفية', 'parole' ); ?></h2>
		<?php if ( $parole_tabs ) : ?>
			<div class="sheet__group" role="group" aria-labelledby="fs-cat">
				<span class="sheet__label" id="fs-cat"><?php esc_html_e( 'القسم', 'parole' ); ?></span>
				<div class="chips">
					<a class="chip<?php echo ( is_shop() && ! is_search() ) ? ' is-on' : ''; ?>" href="<?php echo esc_url( parole_shop_url() ); ?>"><?php esc_html_e( 'الكل', 'parole' ); ?></a>
					<?php foreach ( $parole_tabs as $parole_t ) : ?>
						<a class="chip<?php echo $parole_t['on'] ? ' is-on' : ''; ?>" href="<?php echo esc_url( $parole_t['url'] ); ?>"><?php echo esc_html( $parole_t['label'] ); ?></a>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		<?php foreach ( $parole_filters as $parole_i => $parole_g ) : ?>
			<div class="sheet__group" role="group" aria-labelledby="fs-a<?php echo (int) $parole_i; ?>">
				<span class="sheet__label" id="fs-a<?php echo (int) $parole_i; ?>"><?php echo esc_html( $parole_g['label'] ); ?></span>
				<div class="chips"><?php parole_render_attribute_chips( $parole_g ); ?></div>
			</div>
		<?php endforeach; ?>
		<button type="button" class="btn btn--navy btn--block" data-close>
			<?php
			/* translators: %d: number of products */
			echo esc_html( sprintf( __( 'عرض %d منتج', 'parole' ), $parole_total ) );
			?>
		</button>
	</div>
</div>
<?php endif; ?>
<?php
get_footer();
