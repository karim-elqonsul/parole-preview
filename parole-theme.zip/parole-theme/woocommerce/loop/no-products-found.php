<?php
/**
 * Empty catalogue / no filter results (overrides woocommerce/templates/loop/no-products-found.php).
 *
 * @package Parole
 * @version 7.8.0
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="empty-state woocommerce-no-products-found">
	<?php parole_the_icon( 'bean', 'empty-state__icon' ); ?>
	<p class="empty-state__title"><?php esc_html_e( 'لا توجد منتجات بهذا الاختيار', 'parole' ); ?></p>
	<a class="btn btn--navy" href="<?php echo esc_url( parole_shop_url() ); ?>"><?php esc_html_e( 'إظهار الكل', 'parole' ); ?></a>
</div>
