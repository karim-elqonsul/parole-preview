<?php
/**
 * Sorting select (overrides woocommerce/templates/loop/orderby.php) — native ?orderby=.
 *
 * @package Parole
 * @version 9.7.0
 */

defined( 'ABSPATH' ) || exit;
?>
<form class="woocommerce-ordering sort" method="get">
	<label class="sort__label">
		<span><?php esc_html_e( 'ترتيب', 'parole' ); ?></span>
		<select name="orderby" class="orderby" aria-label="<?php esc_attr_e( 'ترتيب المتجر', 'parole' ); ?>">
			<?php foreach ( $catalog_orderby_options as $id => $name ) : ?>
				<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>><?php echo esc_html( $name ); ?></option>
			<?php endforeach; ?>
		</select>
	</label>
	<input type="hidden" name="paged" value="1" />
	<?php wc_query_string_form_fields( null, array( 'orderby', 'submit', 'paged', 'product-page' ) ); ?>
	<noscript><button type="submit" class="btn btn--soft btn--sm"><?php esc_html_e( 'تطبيق', 'parole' ); ?></button></noscript>
</form>
