<?php
/**
 * Product tabs rendered as an accessible accordion (overrides single-product/tabs/tabs.php).
 *
 * @package Parole
 * @version 9.8.0
 */

defined( 'ABSPATH' ) || exit;

$product_tabs = apply_filters( 'woocommerce_product_tabs', array() );
if ( empty( $product_tabs ) ) {
	return;
}
$parole_first = true;
?>
<div class="accordion woocommerce-tabs">
	<?php foreach ( $product_tabs as $key => $product_tab ) : ?>
		<details class="accordion__item" id="tab-<?php echo esc_attr( $key ); ?>"<?php echo $parole_first ? ' open' : ''; ?>>
			<summary class="accordion__head"><span><?php echo wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $product_tab['title'], $key ) ); ?></span><?php parole_the_icon( 'caret-down', 'accordion__caret' ); ?></summary>
			<div class="accordion__body">
				<?php
				if ( isset( $product_tab['callback'] ) ) {
					call_user_func( $product_tab['callback'], $key, $product_tab );
				}
				?>
			</div>
		</details>
		<?php $parole_first = false; ?>
	<?php endforeach; ?>
	<?php do_action( 'woocommerce_product_after_tabs' ); ?>
</div>
