<?php
/**
 * Product page body (overrides woocommerce/templates/content-single-product.php).
 * All standard hooks are kept, so gateway/BNPL/review plugins render as usual.
 *
 * @package Parole
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'pdp', $product ); ?>>
	<div class="pdp__grid">
		<div class="pdp__gallery sticky-col">
			<?php do_action( 'woocommerce_before_single_product_summary' ); ?>
		</div>
		<div class="summary entry-summary pdp__summary">
			<?php do_action( 'woocommerce_single_product_summary' ); ?>
		</div>
	</div>
	<?php do_action( 'woocommerce_after_single_product_summary' ); ?>
</div>
<?php
do_action( 'woocommerce_after_single_product' );
