<?php
/**
 * Single product wrapper (overrides woocommerce/templates/single-product.php).
 *
 * @package Parole
 * @version 1.6.4
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="wrap page-pad pdp-page">
	<?php
	woocommerce_breadcrumb();
	while ( have_posts() ) {
		the_post();
		wc_get_template_part( 'content', 'single-product' );
	}
	?>
</main>
<?php
get_footer();
