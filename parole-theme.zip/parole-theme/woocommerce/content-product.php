<?php
/**
 * PARŌLE product card (overrides woocommerce/templates/content-product.php).
 * Keeps WooCommerce's loop hooks so plugins (wishlists, badges, quick view) still attach.
 *
 * @package Parole
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
	return;
}
$parole_info = parole_product_info( $product );
$parole_link = apply_filters( 'woocommerce_loop_product_link', get_the_permalink(), $product );
?>
<li <?php wc_product_class( 'card', $product ); ?>>
	<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>
	<a class="card__media" href="<?php echo esc_url( $parole_link ); ?>" tabindex="-1" aria-hidden="true">
		<?php
		echo $product->get_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'woocommerce_thumbnail',
			array(
				'class' => 'card__img',
				'sizes' => '(max-width: 760px) 68vw, (max-width: 1100px) 50vw, 25vw',
				'alt'   => '',
			)
		);
		?>
		<?php if ( $parole_info['badge'] ) : ?>
			<span class="card__badge"><?php echo esc_html( $parole_info['badge'] ); ?></span>
		<?php endif; ?>
	</a>
	<?php do_action( 'woocommerce_before_shop_loop_item_title' ); ?>
	<div class="card__body">
		<?php echo parole_eyebrow( $parole_info['en'], 'eyebrow--faint card__eye' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<h3 class="card__title woocommerce-loop-product__title"><a href="<?php echo esc_url( $parole_link ); ?>"><?php echo esc_html( get_the_title() ); ?></a></h3>
		<?php if ( $parole_info['origin'] ) : ?>
			<span class="card__desc"><?php echo esc_html( $parole_info['origin'] ); ?></span>
		<?php endif; ?>
		<?php if ( $parole_info['size'] ) : ?>
			<span class="card__size" dir="ltr"><?php echo esc_html( $parole_info['size'] ); ?></span>
		<?php endif; ?>
		<?php do_action( 'woocommerce_after_shop_loop_item_title' ); // Ratings etc. ?>
	</div>
	<div class="card__foot">
		<span class="card__price price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
		<?php
		woocommerce_template_loop_add_to_cart(
			array(
				'class' => implode(
					' ',
					array_filter(
						array(
							'card__add',
							'button',
							'product_type_' . $product->get_type(),
							$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
							$product->supports( 'ajax_add_to_cart' ) && $product->is_purchasable() && $product->is_in_stock() ? 'ajax_add_to_cart' : '',
						)
					)
				),
			)
		);
		?>
	</div>
	<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
</li>
