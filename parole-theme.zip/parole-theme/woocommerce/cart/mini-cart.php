<?php
/**
 * Cart drawer contents (overrides woocommerce/templates/cart/mini-cart.php).
 * Quantity steppers post to ?wc-ajax=parole_set_qty; remove uses WooCommerce's native remove link.
 *
 * @package Parole
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_mini_cart' );

if ( WC()->cart && ! WC()->cart->is_empty() ) : ?>
	<ul class="mini-cart woocommerce-mini-cart cart_list product_list_widget" role="list">
		<?php
		do_action( 'woocommerce_before_mini_cart_contents' );

		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
			$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

			if ( ! $_product || ! $_product->exists() || $cart_item['quantity'] <= 0 || ! apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
				continue;
			}
			$product_name      = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
			$thumbnail         = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image( 'woocommerce_gallery_thumbnail', array( 'alt' => '' ) ), $cart_item, $cart_item_key );
			$product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
			$line_total        = apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key );
			$sold_individually = $_product->is_sold_individually();
			$max               = $_product->get_max_purchase_quantity();
			?>
			<li class="mini-cart__item woocommerce-mini-cart-item <?php echo esc_attr( apply_filters( 'woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key ) ); ?>" data-key="<?php echo esc_attr( $cart_item_key ); ?>">
				<span class="mini-cart__thumb"><?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<div class="mini-cart__main">
					<?php if ( $product_permalink ) : ?>
						<a class="mini-cart__name" href="<?php echo esc_url( $product_permalink ); ?>"><?php echo wp_kses_post( $product_name ); ?></a>
					<?php else : ?>
						<span class="mini-cart__name"><?php echo wp_kses_post( $product_name ); ?></span>
					<?php endif; ?>
					<?php echo wc_get_formatted_cart_item_data( $cart_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php if ( $sold_individually ) : ?>
						<span class="mini-cart__qty-fixed"><?php esc_html_e( 'الكمية 1', 'parole' ); ?></span>
					<?php else : ?>
						<div class="stepper stepper--sm" data-qty-stepper>
							<button type="button" class="stepper__btn" data-qty-dec aria-label="<?php echo esc_attr( sprintf( /* translators: %s product */ __( 'تقليل كمية %s', 'parole' ), wp_strip_all_tags( $product_name ) ) ); ?>"><?php parole_the_icon( 'minus' ); ?></button>
							<span class="stepper__val" dir="ltr" aria-live="polite" data-qty-val data-max="<?php echo esc_attr( $max > 0 ? $max : '' ); ?>"><?php echo (int) $cart_item['quantity']; ?></span>
							<button type="button" class="stepper__btn" data-qty-inc aria-label="<?php echo esc_attr( sprintf( /* translators: %s product */ __( 'زيادة كمية %s', 'parole' ), wp_strip_all_tags( $product_name ) ) ); ?>"<?php echo ( $max > 0 && $cart_item['quantity'] >= $max ) ? ' disabled' : ''; ?>><?php parole_the_icon( 'plus' ); ?></button>
						</div>
					<?php endif; ?>
				</div>
				<div class="mini-cart__side">
					<span class="mini-cart__total price"><?php echo wp_kses_post( $line_total ); ?></span>
					<?php
					echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						'woocommerce_cart_item_remove_link',
						sprintf(
							'<a role="button" href="%s" class="remove remove_from_cart_button mini-cart__remove" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">%s</a>',
							esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
							/* translators: %s is the product name */
							esc_attr( sprintf( __( 'إزالة %s من السلة', 'parole' ), wp_strip_all_tags( $product_name ) ) ),
							esc_attr( $product_id ),
							esc_attr( $cart_item_key ),
							esc_attr( $_product->get_sku() ),
							esc_html__( 'إزالة', 'parole' )
						),
						$cart_item_key
					);
					?>
				</div>
			</li>
			<?php
		}

		do_action( 'woocommerce_mini_cart_contents' );
		?>
	</ul>

	<div class="drawer__foot">
		<p class="drawer__total woocommerce-mini-cart__total total">
			<span><?php esc_html_e( 'المجموع', 'parole' ); ?></span>
			<span class="price"><?php echo wp_kses_post( WC()->cart->get_cart_subtotal() ); ?></span>
		</p>
		<?php do_action( 'woocommerce_widget_shopping_cart_before_buttons' ); ?>
		<a class="btn btn--navy btn--lg btn--block checkout" href="<?php echo esc_url( wc_get_checkout_url() ); ?>"><?php esc_html_e( 'إتمام الطلب', 'parole' ); ?><?php parole_the_icon( 'arrow-left', 'dir-icon' ); ?></a>
		<a class="drawer__cart-link" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'عرض السلة', 'parole' ); ?></a>
		<?php do_action( 'woocommerce_widget_shopping_cart_after_buttons' ); ?>
	</div>

<?php else : ?>

	<div class="empty-state empty-state--drawer woocommerce-mini-cart__empty-message">
		<?php parole_the_icon( 'coffee', 'empty-state__icon empty-state__icon--beige' ); ?>
		<p class="empty-state__title"><?php esc_html_e( 'سلتك فاضية', 'parole' ); ?></p>
		<p class="empty-state__text"><?php esc_html_e( 'ابدأ بمحصول تحبه.', 'parole' ); ?></p>
		<a class="btn btn--navy" href="<?php echo esc_url( parole_category_url( 'beans' ) ); ?>"><?php esc_html_e( 'تسوّق المحاصيل', 'parole' ); ?></a>
	</div>

<?php endif; ?>

<?php do_action( 'woocommerce_after_mini_cart' ); ?>
