<?php
/**
 * Empty cart page (overrides woocommerce/templates/cart/cart-empty.php).
 *
 * @package Parole
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_cart_is_empty' );
?>
<div class="empty-state empty-state--page">
	<?php parole_the_icon( 'coffee', 'empty-state__icon empty-state__icon--beige' ); ?>
	<p class="empty-state__title cart-empty"><?php esc_html_e( 'سلتك فاضية', 'parole' ); ?></p>
	<p class="empty-state__text"><?php esc_html_e( 'ابدأ بمحصول تحبه.', 'parole' ); ?></p>
	<?php if ( wc_get_page_id( 'shop' ) > 0 ) : ?>
		<a class="btn btn--navy return-to-shop" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', parole_category_url( 'beans' ) ) ); ?>"><?php esc_html_e( 'تسوّق المحاصيل', 'parole' ); ?></a>
	<?php endif; ?>
</div>
