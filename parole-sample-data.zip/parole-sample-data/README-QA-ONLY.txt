FOR QA / STAGING ONLY — DO NOT INSTALL ON LIVE PRODUCTION

PARŌLE QA Sample Data creates TEST categories, attributes, 13 test products with prototype
prices, a test Saudi shipping zone (flat rate + Local pickup) and enables "Cash on delivery"
as a test gateway. Everything it creates is tagged and removed by
Tools → PARŌLE sample data → "Remove sample data". Delete the plugin before launch.
