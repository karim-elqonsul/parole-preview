<?php
/**
 * Plugin Name: PARŌLE — QA Sample Data — FOR QA / STAGING ONLY — DO NOT INSTALL ON LIVE PRODUCTION
 * Description: Creates TEST categories, attributes and products (prototype names/prices) plus test shipping/payment settings, so the theme can be QA'd. Everything it creates is tagged and can be removed in one click. Do not activate on the live store.
 * Version:     1.0.0
 * Author:      PARŌLE
 * License:     GPL-2.0-or-later
 * Requires Plugins: woocommerce
 *
 * @package ParoleSampleData
 */

defined( 'ABSPATH' ) || exit;

const PAROLE_SD_META = '_parole_sample_data';

/* Persistent warning on every admin screen while this plugin is active. */
add_action(
	'admin_notices',
	function () {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-error"><p><strong>FOR QA / STAGING ONLY — DO NOT INSTALL ON LIVE PRODUCTION.</strong> ' . esc_html( 'PARŌLE QA Sample Data is active. Remove its data (Tools → PARŌLE sample data → Remove) and delete the plugin before launch.' ) . '</p></div>';
	}
);

add_action(
	'admin_menu',
	function () {
		add_management_page( 'PARŌLE sample data', 'PARŌLE sample data', 'manage_woocommerce', 'parole-sample-data', 'parole_sd_page' );
	}
);

function parole_sd_page() {
	$done = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	?>
	<div class="wrap">
		<h1>PARŌLE — QA sample data</h1>
		<p style="font-size:15px;color:#b32d2e"><strong>FOR QA / STAGING ONLY — DO NOT INSTALL ON LIVE PRODUCTION.</strong></p>
		<p> Creates 5 categories, 3 attributes, 13 sample products with prototype prices, a Saudi shipping zone (flat rate + Local pickup) and enables “Cash on delivery” as a test gateway.</p>
		<?php if ( $done ) : ?>
			<div class="notice notice-success"><p><?php echo esc_html( 'import' === $done ? 'Sample data imported.' : 'Sample data removed.' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-inline-end:10px">
			<input type="hidden" name="action" value="parole_sd_import"><?php wp_nonce_field( 'parole_sd' ); ?>
			<label style="display:block;margin:8px 0"><input type="checkbox" name="confirm_qa" value="1" required> This is a QA / staging site, not the live store.</label>
			<?php submit_button( 'Import sample data', 'primary', 'submit', false ); ?>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
			<input type="hidden" name="action" value="parole_sd_remove"><?php wp_nonce_field( 'parole_sd' ); ?>
			<?php submit_button( 'Remove sample data', 'delete', 'submit', false ); ?>
		</form>
	</div>
	<?php
}

add_action(
	'admin_post_parole_sd_import',
	function () {
		check_admin_referer( 'parole_sd' );
		if ( ! current_user_can( 'manage_woocommerce' ) || empty( $_POST['confirm_qa'] ) ) {
			wp_die( 'Not allowed: confirm this is a QA / staging site.' );
		}
		parole_sd_import();
		wp_safe_redirect( admin_url( 'tools.php?page=parole-sample-data&done=import' ) );
		exit;
	}
);
add_action(
	'admin_post_parole_sd_remove',
	function () {
		check_admin_referer( 'parole_sd' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'Not allowed' );
		}
		parole_sd_remove();
		wp_safe_redirect( admin_url( 'tools.php?page=parole-sample-data&done=remove' ) );
		exit;
	}
);

/**
 * Upload a bundled image once.
 *
 * @param string $file File name in /images.
 */
function parole_sd_image( $file ) {
	static $cache = array();
	if ( isset( $cache[ $file ] ) ) {
		return $cache[ $file ];
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( $file );
	copy( __DIR__ . '/images/' . $file, $tmp );
	$id = media_handle_sideload(
		array(
			'name'     => $file,
			'tmp_name' => $tmp,
		),
		0
	);
	if ( is_wp_error( $id ) ) {
		return 0;
	}
	update_post_meta( $id, PAROLE_SD_META, 1 );
	$cache[ $file ] = $id;
	return $id;
}

/**
 * Ensure an attribute taxonomy + terms.
 *
 * @param string   $slug  Attribute slug.
 * @param string   $label Label.
 * @param string[] $terms Terms.
 */
function parole_sd_attribute( $slug, $label, $terms ) {
	$tax = wc_attribute_taxonomy_name( $slug );
	if ( ! wc_attribute_taxonomy_id_by_name( $slug ) ) {
		wc_create_attribute(
			array(
				'name'         => $label,
				'slug'         => $slug,
				'type'         => 'select',
				'order_by'     => 'menu_order',
				'has_archives' => false,
			)
		);
		delete_transient( 'wc_attribute_taxonomies' );
		WC_Cache_Helper::invalidate_cache_group( 'woocommerce-attributes' );
	}
	if ( ! taxonomy_exists( $tax ) ) {
		register_taxonomy( $tax, array( 'product' ), array( 'hierarchical' => false ) );
	}
	$ids = array();
	foreach ( $terms as $t ) {
		$term = term_exists( $t, $tax );
		if ( ! $term ) {
			$term = wp_insert_term( $t, $tax );
		}
		if ( ! is_wp_error( $term ) ) {
			$ids[ $t ] = (int) $term['term_id'];
		}
	}
	return array(
		'id'    => wc_attribute_taxonomy_id_by_name( $slug ),
		'tax'   => $tax,
		'terms' => $ids,
	);
}

/**
 * Product attribute object.
 */
function parole_sd_attr_obj( $a, $names, $variation = false ) {
	$o = new WC_Product_Attribute();
	$o->set_id( $a['id'] );
	$o->set_name( $a['tax'] );
	$o->set_options( array_map( function ( $n ) use ( $a ) { return $a['terms'][ $n ]; }, $names ) );
	$o->set_visible( true );
	$o->set_variation( $variation );
	return $o;
}

function parole_sd_import() {
	if ( get_option( 'parole_sd_imported' ) ) {
		return;
	}
	// Categories (slugs = theme defaults).
	$cats = array(
		'coffee-beans'  => array( 'المحاصيل', 'Coffee beans', 'إثيوبيا · كولومبيا · أوغندا', 'parole-beans-bags.jpg', 1 ),
		'bundles-gifts' => array( 'الباقات والهدايا', 'Bundles & gifts', '', 'parole-discovery-box.jpg', 2 ),
		'easy-brew'     => array( 'أظرف بارولي', 'Easy brew', '', 'parole-easy-brew.jpg', 3 ),
		'brewing-tools' => array( 'أدوات التحضير', 'Brewing tools', '', 'parole-tools.jpg', 4 ),
		'parole-goods'  => array( 'منتجات بارولي', 'PARŌLE goods', '', 'parole-goods.jpg', 5 ),
	);
	$cat_ids = array();
	foreach ( $cats as $slug => $c ) {
		$t = get_term_by( 'slug', $slug, 'product_cat' );
		$id = $t ? $t->term_id : wp_insert_term( $c[0], 'product_cat', array( 'slug' => $slug, 'description' => $c[2] ) )['term_id'];
		update_term_meta( $id, 'parole_en', $c[1] );
		update_term_meta( $id, 'thumbnail_id', parole_sd_image( $c[3] ) );
		update_term_meta( $id, 'order', $c[4] );
		update_term_meta( $id, PAROLE_SD_META, 1 );
		$cat_ids[ $slug ] = $id;
	}

	$origin = parole_sd_attribute( 'origin', 'المحصول', array( 'إثيوبيا', 'كولومبيا', 'أوغندا', 'محاصيل متنوعة' ) );
	$size   = parole_sd_attribute( 'size', 'الحجم', array( '250g', '3 × 250g', '7 × 12g' ) );
	$grind  = parole_sd_attribute( 'grind', 'الطحن', array( 'حبوب كاملة', 'طحن للتقطير', 'طحن للإسبريسو' ) );

	$guide = 'نقطة بداية جيدة: ١٥ غرام قهوة لكل ٢٥٠ مل ماء على حرارة قريبة من ٩٣°، ثم عدّل حسب ذوقك.';
	$items = array(
		// key, name, cats, en, origin terms, size term, price, image, type, short desc, sale
		array( 'box', 'بوكس ٣ محاصيل', array( 'coffee-beans', 'bundles-gifts' ), 'Discovery box', array(), '3 × 250g', 129, 'parole-discovery-box.jpg', 'simple', 'ثلاثة محاصيل من بارولي في بوكس واحد — إثيوبيا وكولومبيا وأوغندا — لتجرّب الفرق بينها في بيتك.', '', 'إثيوبيا · كولومبيا · أوغندا' ),
		array( 'eth', 'إثيوبيا', array( 'coffee-beans' ), 'Single origin', array( 'إثيوبيا' ), '250g', 68, 'parole-beans-bags.jpg', 'variable', 'محصول مختص من بارولي، يصلك بالطحن اللي تختاره.', '', 'محصول مختص' ),
		array( 'col', 'كولومبيا', array( 'coffee-beans' ), 'Single origin', array( 'كولومبيا' ), '250g', 62, 'parole-beans-bags.jpg', 'variable', 'محصول مختص من بارولي، يصلك بالطحن اللي تختاره.', '', 'محصول مختص' ),
		array( 'uga', 'أوغندا', array( 'coffee-beans' ), 'Single origin', array( 'أوغندا' ), '250g', 58, 'parole-beans-bags.jpg', 'variable', 'محصول مختص من بارولي، يصلك بالطحن اللي تختاره.', '', 'محصول مختص' ),
		array( 'e-eth', 'أظرف إثيوبيا', array( 'easy-brew' ), 'Easy brew', array( 'إثيوبيا' ), '7 × 12g', 42, 'easy-ethiopia.jpg', 'simple', 'محاصيل بارولي في أظرف تقطير جاهزة. علّق الظرف على الكوب واسكب الماء الساخن ببطء.', '', '' ),
		array( 'e-col', 'أظرف كولومبيا', array( 'easy-brew' ), 'Easy brew', array( 'كولومبيا' ), '7 × 12g', 42, 'easy-colombia.jpg', 'simple', 'محاصيل بارولي في أظرف تقطير جاهزة. علّق الظرف على الكوب واسكب الماء الساخن ببطء.', '', '' ),
		array( 'e-mix', 'أظرف منوّعة', array( 'easy-brew' ), 'Easy brew', array( 'محاصيل متنوعة' ), '7 × 12g', 45, 'easy-mixed.jpg', 'simple', 'محاصيل بارولي في أظرف تقطير جاهزة. علّق الظرف على الكوب واسكب الماء الساخن ببطء.', 39, '' ),
		array( 'v60', 'قمع تقطير V60', array( 'brewing-tools' ), '', array(), '', 95, 'parole-tools.jpg', 'simple', 'أداة مختارة لتحضير القهوة المختصة في البيت.', '', '' ),
		array( 'srv', 'سيرفر زجاجي', array( 'brewing-tools' ), '', array(), '', 85, 'parole-tools.jpg', 'simple', 'أداة مختارة لتحضير القهوة المختصة في البيت.', '', '' ),
		array( 'scale', 'ميزان تقطير', array( 'brewing-tools' ), '', array(), '', 180, 'parole-tools.jpg', 'simple', 'أداة مختارة لتحضير القهوة المختصة في البيت.', '', '' ),
		array( 'cup', 'كوب بارولي', array( 'parole-goods' ), '', array(), '', 48, 'parole-goods.jpg', 'simple', 'من منتجات بارولي — لطقس قهوتك اليومي.', '', '' ),
		array( 'tote', 'شنطة بارولي', array( 'parole-goods' ), '', array(), '', 55, 'parole-goods.jpg', 'simple', 'من منتجات بارولي — لطقس قهوتك اليومي.', '', '' ),
		array( 'tumbler', 'تمبلر بارولي', array( 'parole-goods' ), '', array(), '', 89, 'parole-goods.jpg', 'simple', 'من منتجات بارولي — لطقس قهوتك اليومي.', '', '' ),
	);

	$ids   = array();
	$order = 0;
	foreach ( $items as $it ) {
		list( $key, $name, $pcats, $en, $origins, $sz, $price, $img, $type, $short, $sale, $origin_line ) = $it;
		$p = 'variable' === $type ? new WC_Product_Variable() : new WC_Product_Simple();
		$p->set_name( $name );
		$p->set_status( 'publish' );
		$p->set_menu_order( ++$order );
		$p->set_short_description( $short );
		$p->set_description( $short );
		$p->set_category_ids( array_map( function ( $s ) use ( $cat_ids ) { return $cat_ids[ $s ]; }, $pcats ) );
		$p->set_image_id( parole_sd_image( $img ) );
		$p->set_sku( 'TEST-' . strtoupper( $key ) );
		$p->set_manage_stock( true );
		$p->set_stock_quantity( 'scale' === $key ? 0 : 25 );
		$p->set_stock_status( 'scale' === $key ? 'outofstock' : 'instock' );
		$attrs = array();
		if ( $origins ) {
			$attrs[] = parole_sd_attr_obj( $origin, $origins );
		}
		if ( $sz ) {
			$attrs[] = parole_sd_attr_obj( $size, array( $sz ) );
		}
		if ( 'variable' === $type ) {
			$attrs[] = parole_sd_attr_obj( $grind, array_keys( $grind['terms'] ), true );
		} else {
			$p->set_regular_price( (string) $price );
			if ( $sale ) {
				$p->set_sale_price( (string) $sale );
			}
		}
		$p->set_attributes( $attrs );
		if ( $en ) {
			$p->update_meta_data( '_parole_en', $en );
		}
		if ( $origin_line ) {
			$p->update_meta_data( '_parole_origin', $origin_line );
		}
		if ( in_array( 'coffee-beans', $pcats, true ) || in_array( 'easy-brew', $pcats, true ) ) {
			$p->update_meta_data( '_parole_brew', $guide );
		}
		$p->update_meta_data( PAROLE_SD_META, 1 );
		$id = $p->save();
		if ( 'variable' === $type ) {
			foreach ( $grind['terms'] as $tname => $tid ) {
				$v = new WC_Product_Variation();
				$v->set_parent_id( $id );
				$v->set_attributes( array( $grind['tax'] => get_term( $tid )->slug ) );
				$v->set_regular_price( (string) $price );
				$v->set_manage_stock( false );
				$v->set_stock_status( 'instock' );
				$v->update_meta_data( PAROLE_SD_META, 1 );
				$v->save();
			}
			WC_Product_Variable::sync( $id );
		}
		$ids[ $key ] = $id;
	}

	set_theme_mod( 'parole_camp_product', $ids['box'] );
	set_theme_mod( 'parole_hero_product', $ids['box'] );

	// Test shipping: Saudi Arabia zone with flat rate + Local pickup (branch pickup).
	if ( class_exists( 'WC_Shipping_Zone' ) ) {
		$zone = new WC_Shipping_Zone();
		$zone->set_zone_name( 'السعودية (QA)' );
		$zone->add_location( 'SA', 'country' );
		$zone->save();
		$flat = $zone->add_shipping_method( 'flat_rate' );
		update_option(
			'woocommerce_flat_rate_' . $flat . '_settings',
			array(
				'title'      => 'توصيل',
				'tax_status' => 'none',
				'cost'       => '25',
			)
		);
		$pick = $zone->add_shipping_method( 'local_pickup' );
		update_option(
			'woocommerce_local_pickup_' . $pick . '_settings',
			array(
				'title'      => 'استلام من الفرع',
				'tax_status' => 'none',
				'cost'       => '0',
			)
		);
		update_option( 'parole_sd_zone', $zone->get_id() );
	}
	// Test gateway only.
	$cod            = get_option( 'woocommerce_cod_settings', array() );
	$cod['enabled'] = 'yes';
	$cod['title']   = 'الدفع عند الاستلام (اختبار)';
	update_option( 'woocommerce_cod_settings', $cod );

	update_option( 'parole_sd_imported', time() );
	wc_delete_product_transients();
}

function parole_sd_remove() {
	$products = get_posts(
		array(
			'post_type'      => array( 'product', 'product_variation' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'meta_key'       => PAROLE_SD_META, // phpcs:ignore WordPress.DB.SlowDBQuery
			'fields'         => 'ids',
		)
	);
	foreach ( $products as $id ) {
		wp_delete_post( $id, true );
	}
	$media = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'meta_key'       => PAROLE_SD_META, // phpcs:ignore WordPress.DB.SlowDBQuery
			'fields'         => 'ids',
		)
	);
	foreach ( $media as $id ) {
		wp_delete_attachment( $id, true );
	}
	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'meta_key'   => PAROLE_SD_META, // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			wp_delete_term( $t->term_id, 'product_cat' );
		}
	}
	$zone_id = (int) get_option( 'parole_sd_zone' );
	if ( $zone_id && class_exists( 'WC_Shipping_Zone' ) ) {
		( new WC_Shipping_Zone( $zone_id ) )->delete();
	}
	$cod            = get_option( 'woocommerce_cod_settings', array() );
	$cod['enabled'] = 'no';
	update_option( 'woocommerce_cod_settings', $cod );
	remove_theme_mod( 'parole_camp_product' );
	remove_theme_mod( 'parole_hero_product' );
	delete_option( 'parole_sd_imported' );
	delete_option( 'parole_sd_zone' );
	wc_delete_product_transients();
}

/**
 * WordPress Playground runs on SQLite; WooCommerce's checkout stock-reservation query
 * (wc_reserved_stock) is MySQL-specific there. Disable reservation ONLY on SQLite test sites.
 */
if ( defined( 'DB_ENGINE' ) && 'sqlite' === DB_ENGINE ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}
